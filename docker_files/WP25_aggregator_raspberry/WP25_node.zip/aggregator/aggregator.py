"""
WP2.5.i -- Central aggregator.

Subscribes to every WP2.x ESP32 node's MQTT topic, merges the latest reading
from each with CAN bus data (see get_can_data() below -- the CAN interface
itself is now read for real, but per-signal decoding is still stubbed
pending a DBC file for this vehicle) and GPS data (STUBBED -- see
get_gps_data(), pending SIM7600 setup), assembles the unified record matching
WP2_payload_schema.json, writes it to TimescaleDB, and republishes it as a
single combined MQTT message.

Nothing here waits on CAN or GPS hardware -- both fall back to clearly-marked
placeholder values whenever real data isn't available, so the rest of the
pipeline is fully testable regardless of what hardware is currently attached.

Also subscribes to "bus/test/#" -- two additional, test-only topics
(CAN_OVERRIDE_TOPIC, FAULT_TOPIC, defined below) let a test tool (see the
sensor emulator) push dummy energy data and/or simulated per-WP faults
through this same real pipeline, for testing before real CAN/DBC hardware
or genuine sensor fault detection exist.
"""

import json
import os
import threading
import time
from datetime import datetime, timezone

import can
import paho.mqtt.client as mqtt
import psycopg2
from psycopg2.extras import Json

MQTT_BROKER = os.environ.get("MQTT_BROKER", "mosquitto")
MQTT_PORT = int(os.environ.get("MQTT_PORT", 1883))

DB_HOST = os.environ.get("DB_HOST", "timescaledb")
DB_PORT = int(os.environ.get("DB_PORT", 5432))
DB_NAME = os.environ.get("DB_NAME", "wp2data")
DB_USER = os.environ.get("DB_USER", "wp2user")
DB_PASSWORD = os.environ.get("DB_PASSWORD", "change_me_wp2")

VEHICLE_ID = os.environ.get("VEHICLE_ID", "BUS_2034")
TRIP_ID = int(os.environ.get("TRIP_ID", 51))

AGGREGATION_INTERVAL_SEC = float(os.environ.get("AGGREGATION_INTERVAL_SEC", 1.0))
COMBINED_PUBLISH_TOPIC = "bus/unified/combined"

# --- CAN bus configuration -------------------------------------------------
# Which SocketCAN network interface to read from. "can0" is what a PiCAN3
# HAT (or any other MCP2515-based SocketCAN HAT) exposes as a normal Linux
# network interface once its kernel driver has probed successfully -- see
# the project's README ("CAN-HAT" setup step) for how that's brought up.
# Overridable via env in case a future Pi ends up using a different
# interface name (e.g. a second HAT as "can1").
CAN_CHANNEL = os.environ.get("CAN_CHANNEL", "can0")

# python-can's backend/interface name for Linux SocketCAN. This project
# only ever talks to SocketCAN interfaces, so this is not exposed as an
# env var -- there is nothing else to switch it to here.
CAN_BUSTYPE = "socketcan"

# Seconds to wait between attempts to (re)open the CAN bus when it's
# missing or has just failed. Short enough that the aggregator notices the
# interface coming back quickly (HAT plugged in, interface brought back
# up after being down), long enough not to spam the logs while it's gone.
CAN_RECONNECT_DELAY_SEC = 5

TOPIC_MAP = {
    "bus/env/wp211_front":  ("wp21i", "wp211_front"),
    "bus/env/wp212_middle": ("wp21i", "wp212_middle"),
    "bus/env/wp213_rear":   ("wp21i", "wp213_rear"),
    "bus/env/wp221_front":  ("wp22i", "wp221_front"),
    "bus/env/wp222_right":  ("wp22i", "wp222_right"),
    "bus/env/wp223_left":   ("wp22i", "wp223_left"),
    "bus/env/wp231_front":  ("wp23i", "wp231_front"),
    "bus/env/wp232_middle": ("wp23i", "wp232_middle"),
    "bus/env/wp233_rear":   ("wp23i", "wp233_rear"),
}
THERMAL_DUMMY_TOPIC = "bus/env/thermal_dummy"
# Second, optional thermal dummy. The bus only ever had one physical WP2.6.i
# manikin when this project started, so there is a single "primary" topic
# above for backwards compatibility with all historical data -- this second
# topic is additive: nothing publishes here unless a second dummy (real or
# emulated via the sensor emulator tool) actually sends to it, and
# thermal_dummy_wp26i_2 in the combined record (see build_unified_record())
# simply stays null until it does, exactly like the CAN/GPS stubs above.
THERMAL_DUMMY_2_TOPIC = "bus/env/thermal_dummy_2"
WP2TM_TOPIC = "bus/env/wp2tm"

# --- Test-only injection topics ------------------------------------------
# Deliberately under "bus/test/", never "bus/env/", so they can never be
# confused with a real sensor/hardware source, and so a wildcard
# subscriber watching only "bus/env/#" (e.g. a future analysis tool) never
# sees test traffic mixed in with real data.
#
# CAN_OVERRIDE_TOPIC: publish a dict here (the sensor emulator's "energy"
# section does this) and get_can_data() returns it verbatim instead of the
# real CAN-hardware-derived reading -- lets the wp25i energy fields be
# exercised through the FULL real pipeline (local DB, forwarder, central
# broker, dashboard) before a DBC file, or even the CAN-HAT itself, exists.
# Publish an empty dict {} to clear the override and go back to whatever
# get_can_data() would normally return.
CAN_OVERRIDE_TOPIC = "bus/test/can_override"

# FAULT_TOPIC: publish {"action": "add", "source": "<wp>", "message": "..."}
# to append a single fault to diagnostics.sensor_faults (see
# WP2_payload_schema.json), or {"action": "add", "faults": [{"source":...,
# "message":...}, ...]} to append several at once in one message, or
# {"action": "clear"} to empty the list. This is this project's only
# mechanism for simulating a WP2.x node reporting a fault, since no real
# hardware fault-detection logic exists anywhere yet.
FAULT_TOPIC = "bus/test/fault"

# state_lock guards the MQTT-derived state below (ESP32 sensor readings,
# thermal dummy, internal WP2.TM, the test-injection state). CAN hardware
# state has its own separate lock (can_lock, defined further down next to
# the CAN reader) because it is written by a different background thread
# and there is no reason for the CAN thread and the MQTT thread to ever
# wait on each other.
state_lock = threading.Lock()
latest_bus_environment = {}
latest_thermal_dummy_surface = None
latest_thermal_dummy_2_surface = None
latest_internal_wp2tm = None

# Test-injection state (see CAN_OVERRIDE_TOPIC / FAULT_TOPIC above).
# Written only in on_message(); read only in build_unified_record() --
# both always while holding state_lock, so no separate lock is needed for
# these two even though they're logically distinct from the ESP32 state
# above.
can_override = None
sensor_faults = []

# True only while this process's MQTT client is currently connected to the
# local broker. Set by on_connect()/on_disconnect() below (not
# on_message(), since those fire outside of any per-message context) --
# its own small lock rather than state_lock, since it's updated from
# paho-mqtt's connection callbacks rather than the message-handling path.
mqtt_state_lock = threading.Lock()
mqtt_connected = False

# --- CAN bus reading ---------------------------------------------------
#
# Real CAN-bus support via python-can's SocketCAN backend. This mirrors
# the connection-retry / background-thread pattern already used for MQTT
# above: a dedicated background thread (_can_reader_thread, started from
# main()) owns the CAN bus object and keeps retrying to open it if the
# interface is missing or drops, while get_can_data() itself never blocks
# on hardware -- it only ever reads the latest state that thread observed,
# protected by can_lock.
#
# IMPORTANT -- why the actual CAN *signals* are still None:
# As of this implementation, there is no DBC file or documented CAN ID /
# signal mapping for this vehicle (a MAN electric bus). Because of that,
# this code deliberately does NOT attempt to decode any of the named
# signals below (fuel_heater_hours, hvess_remaining_distance_km, etc.)
# from the raw CAN frames it receives. Guessing CAN IDs, byte offsets, or
# scaling factors would produce plausible-looking but WRONG values, which
# is worse than leaving them as None: silently wrong data could corrupt
# the research dataset in a way that's hard to detect after the fact.
#
# What this code DOES do is prove the plumbing works end to end -- open
# the bus, read real frames, survive the interface disappearing and
# coming back -- so that once a DBC/signal mapping is available, the ONLY
# remaining work is filling in the decoding step inside get_can_data();
# no threading, Docker networking, or fallback-handling work will be left
# to do at that point.

# Guards can_bus_connected and can_frame_count below. Written only by
# _can_reader_thread(); read only by get_can_data().
can_lock = threading.Lock()

# True only while a real socketcan Bus object is currently open on
# CAN_CHANNEL. False whenever the interface doesn't exist, isn't up, or
# just failed -- this is exactly what get_can_data() checks to decide
# whether to report "stub_no_can_hardware".
can_bus_connected = False

# Total number of CAN frames observed since the bus was last (re)opened.
# This is purely diagnostic -- it proves real traffic is flowing on the
# bus -- and is never decoded into any of the named signals (see the
# module-level comment above for why).
can_frame_count = 0


def _can_reader_thread():
    """
    Runs forever in a background thread (started from main()). Opens a
    python-can Bus on CAN_CHANNEL and continuously reads incoming frames,
    exactly the way the MQTT client's own background loop (client.loop_start()
    in main()) continuously reads incoming MQTT messages elsewhere in this
    file. If opening the bus fails (interface doesn't exist yet -- e.g. no
    HAT installed) or an already-open bus raises while reading (interface
    was brought down, HAT unplugged mid-operation), this function catches
    the error, marks the bus as disconnected so get_can_data() falls back
    to reporting "stub_no_can_hardware", waits, and retries -- forever.
    This is the same "never crash the aggregator, just degrade gracefully"
    pattern already used for the DB and MQTT connections in main().
    """
    global can_bus_connected, can_frame_count

    while True:
        try:
            # NOTE: python-can requires the SocketCAN interface to already
            # exist and be administratively "up" at the OS level (e.g.
            # via `sudo ip link set can0 up type can bitrate 250000`, see
            # the project's README) -- this call does not create or
            # configure the interface itself, it only opens a socket
            # against one that's already there. If can0 doesn't exist at
            # all, this raises immediately and we fall into the except
            # block below and retry.
            bus = can.Bus(channel=CAN_CHANNEL, interface=CAN_BUSTYPE)

            with can_lock:
                can_bus_connected = True
                can_frame_count = 0
            print(f"[CAN] Connected to {CAN_CHANNEL}.")

            # Iterating a python-can Bus blocks and yields one Message
            # object per incoming CAN frame -- this is the CAN equivalent
            # of the MQTT client's on_message callback above, just
            # written as a plain blocking loop instead of a callback,
            # since python-can's API is iterator-based rather than
            # event-based. This loop runs until the bus raises (interface
            # went away) or the process exits.
            for _message in bus:
                with can_lock:
                    can_frame_count += 1
                # Deliberately not decoding _message here -- see the
                # module-level comment above for why (no DBC / signal
                # mapping available yet for this vehicle). Once one
                # exists, this is where per-signal decoding would go,
                # writing results into a small dict guarded by can_lock
                # for get_can_data() to read back out.

        except Exception as e:
            # Caught broadly and deliberately: python-can can raise
            # several different exception types depending on *how* the
            # interface is broken (doesn't exist yet, was removed while
            # open, permission denied, etc.), and the correct response is
            # identical in every case -- log it, mark CAN as unavailable,
            # wait, and retry. Letting any of these propagate would crash
            # this thread (and, since it's the only thing that would
            # notice, silently stop CAN reading forever without anyone
            # knowing) without affecting the ESP32/MQTT/DB pipeline, which
            # must keep working regardless of CAN hardware state.
            with can_lock:
                can_bus_connected = False
            print(
                f"[CAN] Bus unavailable on {CAN_CHANNEL} ({e}); "
                f"retrying in {CAN_RECONNECT_DELAY_SEC}s..."
            )
            time.sleep(CAN_RECONNECT_DELAY_SEC)


def get_can_data(override=None):
    """
    Returns the CAN-derived portion of the combined record (the "wp25i"
    block in build_unified_record() below). Called once per aggregation
    cycle -- never touches hardware directly, only reads the state that
    _can_reader_thread() last wrote, so it can never block or slow down
    the aggregation loop even if the CAN bus itself is misbehaving.

    If `override` is given (the current value of the module-level
    can_override, set via CAN_OVERRIDE_TOPIC -- see on_message()), it is
    returned verbatim, tagged "_data_source": "test_override", instead of
    the real hardware-derived reading below. This lets the sensor emulator
    (or any other test tool) push dummy energy/CAN values through the
    FULL real pipeline -- local DB, forwarder, central broker, dashboard
    -- without needing a DBC file or the CAN-HAT itself. It's passed in as
    a parameter rather than read directly from the global here because
    this function is called from inside build_unified_record()'s own
    `with state_lock:` block, and state_lock is not reentrant -- reading
    the (state_lock-guarded) global directly in here would deadlock.

    Otherwise, every signal is currently always None, because there is no
    DBC file / documented CAN ID mapping for this vehicle yet (see the
    module-level comment above the CAN section for the full explanation of
    why this is intentional and should not be "fixed" by guessing at a
    mapping).

    The "_data_source" field distinguishes *why* the values are None,
    which matters for debugging once a DBC file does become available:
      - "stub_no_can_hardware": the CAN interface itself isn't up yet, or
        hasn't produced any frames yet (no HAT, HAT not wired to the
        vehicle bus, or the interface was brought down / the HAT was
        unplugged at runtime).
      - "stub_no_dbc_mapping": the CAN interface IS up and has received
        at least one real frame (proven by can_frame_count > 0), but this
        function still doesn't decode any signals from it, because no
        DBC/signal documentation has been provided for this vehicle. This
        is the value that should change to "live_can_hardware" once real
        decoding is implemented against an actual DBC file for the named
        signals below -- do not flip it manually without implementing
        that decoding, since downstream consumers use this field to tell
        real data apart from placeholder data.
    """
    if override is not None:
        return {**override, "_data_source": "test_override"}

    with can_lock:
        connected = can_bus_connected
        frame_count = can_frame_count

    if connected and frame_count > 0:
        # Bus is open and real traffic has been observed, but nothing in
        # this file decodes it into named signals yet -- see the
        # docstring above.
        data_source = "stub_no_dbc_mapping"
    else:
        # Either the interface isn't up at all, or it just opened and
        # hasn't seen a single frame yet -- from the aggregator's point
        # of view this is indistinguishable from "no working hardware".
        data_source = "stub_no_can_hardware"

    return {
        "fuel_heater_hours": None,
        "hvess_remaining_distance_km": None,
        "operational_soc_percent": None,
        "cumulated_energy_charged_kwh": None,
        "regenerative_braking_cumulated_energy_kwh": None,
        "hvac_cumulated_energy_kwh": None,
        "air_compressor_cumulated_energy_kwh": None,
        "auxiliaries_cumulated_energy_kwh": None,
        "_data_source": data_source,
    }


def get_gps_data():
    return {
        "aps": None,
        "lat": None,
        "lon": None,
        "speed_kmh": None,
        "clo": None,
        "met": None,
        "_data_source": "stub_no_gps_hardware",
    }


def on_connect(client, userdata, flags, reason_code, properties=None):
    global mqtt_connected
    with mqtt_state_lock:
        mqtt_connected = True
    print(f"[MQTT] Connected (reason_code={reason_code}). Subscribing to bus/env/# and bus/test/#")
    client.subscribe("bus/env/#")
    # bus/test/# carries the two test-injection topics (CAN_OVERRIDE_TOPIC,
    # FAULT_TOPIC) -- a separate wildcard subscription so it's obvious at a
    # glance in the logs that this is a distinct, test-only concern from
    # the real sensor data on bus/env/#.
    client.subscribe("bus/test/#")


def on_disconnect(client, userdata, flags, reason_code, properties=None):
    global mqtt_connected
    with mqtt_state_lock:
        mqtt_connected = False
    print(f"[MQTT] Disconnected (reason_code={reason_code}); paho will auto-reconnect.")


def on_message(client, userdata, msg):
    global latest_thermal_dummy_surface, latest_thermal_dummy_2_surface, latest_internal_wp2tm
    global can_override, sensor_faults

    try:
        payload = json.loads(msg.payload.decode("utf-8"))
    except (json.JSONDecodeError, UnicodeDecodeError) as e:
        print(f"[MQTT] Bad payload on {msg.topic}: {e}")
        return

    with state_lock:
        if msg.topic in TOPIC_MAP:
            group, node = TOPIC_MAP[msg.topic]
            latest_bus_environment.setdefault(group, {})[node] = payload
        elif msg.topic == THERMAL_DUMMY_TOPIC:
            latest_thermal_dummy_surface = payload.get("thermal_dummy", {}).get("surface")
        elif msg.topic == THERMAL_DUMMY_2_TOPIC:
            # Same payload shape as the primary thermal dummy above
            # ({"thermal_dummy": {"surface": <value>}}) -- only the topic
            # differs, so a publisher (real second manikin, or the sensor
            # emulator tool) can reuse identical message-building logic
            # for either dummy, just picking which topic to send to.
            latest_thermal_dummy_2_surface = payload.get("thermal_dummy", {}).get("surface")
        elif msg.topic == WP2TM_TOPIC:
            latest_internal_wp2tm = payload.get("internal_wp2tm")
        elif msg.topic == CAN_OVERRIDE_TOPIC:
            # An empty dict ({}) clears the override (falsy -> None),
            # reverting to get_can_data()'s normal real-hardware behavior;
            # any non-empty dict is used verbatim as the wp25i block.
            can_override = payload if payload else None
            print(f"[TEST] CAN override {'cleared' if can_override is None else 'set'}.")
        elif msg.topic == FAULT_TOPIC:
            action = payload.get("action")
            if action == "add":
                # Two accepted shapes, both handled the same way below:
                #   {"action": "add", "source": ..., "message": ...}         (one fault)
                #   {"action": "add", "faults": [{"source":..., "message":...}, ...]}  (several at once)
                # "faults" takes priority if both happen to be present, since
                # it's the more specific request.
                new_faults = payload.get("faults")
                if new_faults is None:
                    new_faults = [{"source": payload.get("source", "unknown"), "message": payload.get("message", "")}]
                for f in new_faults:
                    sensor_faults.append(
                        {"source": f.get("source", "unknown"), "message": f.get("message", "")}
                    )
                print(f"[TEST] {len(new_faults)} fault(s) added: {new_faults}")
            elif action == "clear":
                sensor_faults.clear()
                print("[TEST] All injected faults cleared.")


def get_db_connection():
    return psycopg2.connect(
        host=DB_HOST, port=DB_PORT, dbname=DB_NAME, user=DB_USER, password=DB_PASSWORD
    )


def insert_record(conn, record):
    with conn.cursor() as cur:
        cur.execute(
            "INSERT INTO wp2_records (vehicle_id, trip_id, payload) VALUES (%s, %s, %s)",
            (record["vehicle_id"], record["trip_id"], Json(record)),
        )
    conn.commit()


def build_unified_record():
    """
    Assembles one complete combined record for the current aggregation
    cycle: the latest ESP32 sensor readings received over MQTT (read from
    the module-level state dicts under state_lock), plus a fresh read of
    the GPS and CAN stubs/hardware. This is called once per
    AGGREGATION_INTERVAL_SEC from the main loop below; the returned dict
    is both inserted into TimescaleDB as-is and published verbatim on
    COMBINED_PUBLISH_TOPIC.
    """
    now = datetime.now(timezone.utc)

    # Snapshot all MQTT-derived state, plus fresh GPS/CAN reads, under a
    # single lock acquisition so the whole record reflects one consistent
    # instant in time rather than a mix of before/after some other update.
    # can_override is read here (not inside get_can_data()) and passed in
    # as a parameter -- see get_can_data()'s docstring for why reading the
    # state_lock-guarded global from inside a nested call would deadlock.
    with state_lock:
        current_can_override = can_override
        bus_environment = {
            "wp21i": latest_bus_environment.get("wp21i", {}),
            "wp22i": latest_bus_environment.get("wp22i", {}),
            "wp23i": latest_bus_environment.get("wp23i", {}),
            "wp24i": get_gps_data(),
            "wp25i": get_can_data(current_can_override),
        }
        thermal_surface = latest_thermal_dummy_surface
        thermal_surface_2 = latest_thermal_dummy_2_surface
        internal_wp2tm = latest_internal_wp2tm
        # Copied (not referenced) so nothing outside the lock can mutate
        # the module-level list out from under the record we're building.
        faults = list(sensor_faults)

    with can_lock:
        can_hardware_present = can_bus_connected
    with mqtt_state_lock:
        mqtt_is_connected = mqtt_connected

    # Auto-report permanently-missing hardware as faults too, in addition
    # to whatever's been manually injected via FAULT_TOPIC -- this is what
    # replaced the old (non-schema) diagnostics.can_hardware_present /
    # gps_hardware_present fields: WP2_payload_schema.json only has a
    # single flat "sensor_faults" list, so hardware-absence is expressed
    # as an entry in it instead of as its own separate field. Skipped for
    # CAN specifically when a test override is active, since in that case
    # "no hardware" isn't the interesting fact anymore -- the override is.
    if current_can_override is None and not can_hardware_present:
        faults.append({"source": "wp25i", "message": "no_can_hardware"})
    faults.append({"source": "wp24i", "message": "no_gps_hardware"})  # permanent until SIM7600 setup (see get_gps_data())

    return {
        "timestamp": now.isoformat(),
        "timestamp_utc": int(now.timestamp()),
        "vehicle_id": VEHICLE_ID,
        "trip_id": TRIP_ID,
        "bus_environment": bus_environment,
        "thermal_dummy_wp26i": {"surface": thermal_surface} if thermal_surface else None,
        # Second, optional thermal dummy -- see THERMAL_DUMMY_2_TOPIC above.
        # Stays None (and is simply absent from the dashboard's flattened
        # column view) until something actually publishes to
        # bus/env/thermal_dummy_2; no separate "enabled" flag is needed,
        # since presence of real data already tells the story on its own.
        "thermal_dummy_wp26i_2": {"surface": thermal_surface_2} if thermal_surface_2 else None,
        "internal_wp2tm": internal_wp2tm,
        # Matches WP2_payload_schema.json's diagnostics block exactly --
        # do not add fields here without updating that schema file too.
        "diagnostics": {
            "mqtt_connected": mqtt_is_connected,
            "sensor_faults": faults,
            "watchdog_triggered": False,  # no watchdog logic implemented yet
        },
    }


def main():
    """
    Entry point. Connects to TimescaleDB (retrying until it's ready),
    connects to the local MQTT broker (retrying until it's ready), starts
    the CAN background reader thread (which does its own independent
    retry loop and never blocks startup, since CAN hardware may not be
    present at all), then runs the once-per-second aggregation loop until
    the process is stopped.
    """
    print("[AGGREGATOR] Starting WP2.5.i aggregator...")

    # --- TimescaleDB: retry until the container is accepting connections ---
    conn = None
    for attempt in range(30):
        try:
            conn = get_db_connection()
            print("[DB] Connected to TimescaleDB.")
            break
        except psycopg2.OperationalError as e:
            print(f"[DB] Not ready yet ({e}); retrying in 2s... ({attempt + 1}/30)")
            time.sleep(2)
    if conn is None:
        raise RuntimeError("Could not connect to TimescaleDB after 30 attempts.")

    # --- MQTT: set up callbacks, then retry connecting until the broker
    # container is accepting connections ---
    client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
    client.on_connect = on_connect
    client.on_disconnect = on_disconnect
    client.on_message = on_message

    while True:
        try:
            client.connect(MQTT_BROKER, MQTT_PORT, keepalive=30)
            break
        except (ConnectionRefusedError, OSError) as e:
            print(f"[MQTT] Broker not ready yet ({e}); retrying in 2s...")
            time.sleep(2)

    # loop_start() runs paho-mqtt's network loop (and therefore
    # on_message callbacks) on its own background thread, exactly like
    # _can_reader_thread() below runs independently of this main thread.
    client.loop_start()

    # --- CAN: start the background reader thread. Unlike the DB/MQTT
    # connections above, this is NOT retried here before continuing --
    # CAN hardware may be completely absent (no HAT installed yet), and
    # the aggregator must keep publishing ESP32/GPS data regardless. The
    # thread itself retries opening the bus forever; get_can_data() just
    # reports "no hardware" until it succeeds. daemon=True so this thread
    # never keeps the process alive on its own if the main loop exits.
    can_thread = threading.Thread(target=_can_reader_thread, daemon=True)
    can_thread.start()

    try:
        while True:
            time.sleep(AGGREGATION_INTERVAL_SEC)
            record = build_unified_record()

            try:
                insert_record(conn, record)
            except psycopg2.Error as e:
                print(f"[DB] Insert failed: {e}")
                conn.rollback()

            client.publish(COMBINED_PUBLISH_TOPIC, json.dumps(record), qos=1)
            print(f"[AGGREGATOR] Published combined record @ {record['timestamp']}")

    except KeyboardInterrupt:
        pass
    finally:
        client.loop_stop()
        client.disconnect()
        conn.close()


if __name__ == "__main__":
    main()
