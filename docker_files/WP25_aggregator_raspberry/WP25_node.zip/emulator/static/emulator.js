// WP2.5.i sensor emulator -- front-end logic.
//
// Two kinds of sections in the page:
//   - ".node-card" -- simulates a real WP2.x sensor/thermal-manikin node.
//     Clicking its "Send" button builds a JSON payload from that card's
//     own inputs (shape depends on the card's data-shape attribute -- see
//     buildPayload() below) and POSTs it to this server's /publish
//     endpoint, which republishes it on the local MQTT broker exactly as
//     if that node had sent it. These are also what "Send all enabled
//     sensor sections" (below) sends.
//   - ".test-card" -- the two test-only injection controls (CAN/energy
//     override, fault injection). These are deliberately NOT part of
//     "Send all", since they aren't simulated sensors -- they have their
//     own dedicated buttons instead (see wireCanOverrideCard() /
//     wireFaultCard() below).

// Poll /health periodically and show whether the emulator's own MQTT
// client is currently connected to the local broker -- if it isn't,
// every "Send" click below would just fail with a clear 503, but showing
// this up front avoids the confusion of "why did my click do nothing".
async function refreshConnectionIndicator() {
  const indicator = document.getElementById("connIndicator");
  try {
    const res = await fetch("/health");
    const data = await res.json();
    if (data.mqtt_connected) {
      indicator.textContent = "broker: connected";
      indicator.className = "conn-indicator conn-ok";
    } else {
      indicator.textContent = "broker: not connected";
      indicator.className = "conn-indicator conn-bad";
    }
  } catch (e) {
    indicator.textContent = "broker: unknown (page offline?)";
    indicator.className = "conn-indicator conn-bad";
  }
}

// Reads a single [data-field] input's value, honoring data-field-type:
//   "bool" (a checkbox)         -> true/false
//   (anything else, default)   -> parsed as a float, or null if blank
function readFieldValue(input) {
  if (input.dataset.fieldType === "bool") {
    return input.checked;
  }
  const raw = input.value;
  return raw === "" ? null : parseFloat(raw);
}

// Reads every direct (non-nested) "[data-field]" input inside a container
// and returns a flat object of {fieldName: value}. Used for cards whose
// data-field names have no "." in them -- WP2.1.i/WP2.2.i/WP2.3.i nodes,
// WP2.TM, and the CAN/energy override card, all of which map to a flat
// object in WP2_payload_schema.json (no nested sub-objects).
function readFlatFields(container) {
  const fields = {};
  container.querySelectorAll("[data-field]").forEach((input) => {
    fields[input.dataset.field] = readFieldValue(input);
  });
  return fields;
}

// Reads every "[data-field]" input inside a container whose data-field is
// written as "group.field" (e.g. "head.temp_c") and rebuilds the nested
// object WP2_payload_schema.json's thermal_dummy_wp26i.surface expects --
// {head: {temp_c: ...}, neck: {...}, ...}. Every thermal-dummy field is
// dotted like this; there are no bare (non-nested) fields in that card.
function readNestedSurfaceFields(container) {
  const surface = {};
  container.querySelectorAll("[data-field]").forEach((input) => {
    const [group, field] = input.dataset.field.split(".");
    if (!surface[group]) surface[group] = {};
    surface[group][field] = readFieldValue(input);
  });
  return surface;
}

// Builds the exact JSON payload aggregator.py expects for a given
// ".node-card", based on its data-shape attribute:
//   (none)            -> the fields themselves, flat, e.g.
//                         {c1_temp_C_head_standing: 23.4, ...}
//                         (matches WP2.1.i/WP2.2.i/WP2.3.i, which
//                         aggregator.py's TOPIC_MAP stores verbatim under
//                         bus_environment.<group>.<node>)
//   "thermal_dummy"   -> {"thermal_dummy": {"surface": {...nested...}}}
//                         (matches on_message()'s handling of both
//                         THERMAL_DUMMY_TOPIC and THERMAL_DUMMY_2_TOPIC)
//   "wp2tm"           -> {"internal_wp2tm": {...28 flat fields...}}
//                         (matches on_message()'s handling of WP2TM_TOPIC)
function buildPayload(card) {
  const shape = card.dataset.shape;

  if (shape === "thermal_dummy") {
    return { thermal_dummy: { surface: readNestedSurfaceFields(card) } };
  }
  if (shape === "wp2tm") {
    return { internal_wp2tm: readFlatFields(card) };
  }
  return readFlatFields(card);
}

// Publishes {topic, payload} to /publish and returns the parsed response,
// throwing an Error with a human-readable message on any failure. Shared
// by both node-card sending (sendCard() below) and the two dedicated
// test-card controls (CAN override, fault injection), so all three report
// errors (broker down, bad topic, timeout) the same way.
async function publish(topic, payload) {
  const res = await fetch("/publish", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ topic, payload }),
  });
  if (res.ok) return res.json();
  const body = await res.json().catch(() => ({}));
  throw new Error(body.detail || String(res.status));
}

// Sends one node-card's payload to /publish and updates that card's own
// status text in place. Returns true on success, false on failure, so
// "Send all" (below) can report how many succeeded.
async function sendCard(card) {
  const statusEl = card.querySelector(".node-status");
  const topic = card.dataset.topic;

  statusEl.textContent = "Sending...";
  statusEl.className = "node-status muted";

  try {
    await publish(topic, buildPayload(card));
    statusEl.textContent = "Sent @ " + new Date().toLocaleTimeString();
    statusEl.className = "node-status success";
    return true;
  } catch (e) {
    statusEl.textContent = "Failed: " + e.message;
    statusEl.className = "node-status error";
    return false;
  }
}

function wireIndividualSendButtons() {
  document.querySelectorAll(".node-card").forEach((card) => {
    const btn = card.querySelector(".send-node-btn");
    btn.addEventListener("click", () => sendCard(card));
  });
}

// The second thermal dummy starts disabled (unchecked) -- its inputs and
// Send button are only enabled once the checkbox is ticked, so an idle
// "Send all" click never accidentally starts simulating a manikin that
// isn't meant to be part of the current test run.
function wireDummy2Toggle() {
  const checkbox = document.getElementById("dummy2Enabled");
  const card = document.getElementById("dummy2Card");
  checkbox.addEventListener("change", () => {
    const enabled = checkbox.checked;
    card.querySelectorAll("fieldset").forEach((fs) => {
      fs.disabled = !enabled;
    });
    card.querySelector(".send-node-btn").disabled = !enabled;
    card.classList.toggle("card-disabled", !enabled);
  });
}

// "Send all enabled sensor sections now": every ".node-card" whose Send
// button isn't disabled (i.e. everything except a not-yet-enabled second
// thermal dummy) gets sent, one after another, and the toolbar shows a
// simple success/failure count once they're all done. Deliberately
// excludes the two ".test-card" controls (CAN override, fault injection)
// -- those aren't simulated sensors, and are sent independently via their
// own buttons (see wireCanOverrideCard() / wireFaultCard()).
function wireSendAll() {
  document.getElementById("sendAllBtn").addEventListener("click", async () => {
    const statusEl = document.getElementById("globalStatus");
    const cards = Array.from(document.querySelectorAll(".node-card")).filter(
      (card) => !card.querySelector(".send-node-btn").disabled
    );
    statusEl.textContent = `Sending ${cards.length} section(s)...`;

    let succeeded = 0;
    for (const card of cards) {
      if (await sendCard(card)) succeeded += 1;
    }

    statusEl.textContent = `Done: ${succeeded}/${cards.length} sent successfully.`;
  });
}

// Energy/CAN override test control (bus/test/can_override). "Set
// override" publishes the 8 wp25i-shaped fields as-is (no wrapper object
// -- aggregator.py's on_message() stores whatever's published here
// directly as the module-level can_override). "Clear override" publishes
// an empty object, which on_message() treats as falsy and reverts
// get_can_data() to its normal real-hardware/stub behavior.
function wireCanOverrideCard() {
  const card = document.getElementById("canOverrideCard");
  const statusEl = document.getElementById("overrideStatus");
  const topic = card.dataset.topic;

  document.getElementById("setOverrideBtn").addEventListener("click", async () => {
    statusEl.textContent = "Sending...";
    statusEl.className = "node-status muted";
    try {
      await publish(topic, readFlatFields(card));
      statusEl.textContent = "Override set @ " + new Date().toLocaleTimeString();
      statusEl.className = "node-status success";
    } catch (e) {
      statusEl.textContent = "Failed: " + e.message;
      statusEl.className = "node-status error";
    }
  });

  document.getElementById("clearOverrideBtn").addEventListener("click", async () => {
    statusEl.textContent = "Clearing...";
    statusEl.className = "node-status muted";
    try {
      await publish(topic, {});
      statusEl.textContent = "Override cleared @ " + new Date().toLocaleTimeString();
      statusEl.className = "node-status success";
    } catch (e) {
      statusEl.textContent = "Failed: " + e.message;
      statusEl.className = "node-status error";
    }
  });
}

// Fault-injection test control (bus/test/fault). #faultRows holds one or
// more ".fault-row" elements, each a {source, message} pair; "Add
// fault(s)" always collects every current row and publishes them all in
// a single message -- {"action": "add", "faults": [...]}} -- which
// aggregator.py's on_message() appends to the module-level sensor_faults
// list in one go (see the FAULT_TOPIC comment in aggregator.py). This
// means several simulated faults can land in the very same aggregation
// cycle instead of needing one publish (and one MQTT round-trip) per
// fault. "Clear all injected faults" publishes {"action": "clear"},
// emptying that list (this does NOT clear the auto-appended
// no_can_hardware/no_gps_hardware entries build_unified_record() adds
// itself when that hardware is genuinely absent -- those aren't stored in
// sensor_faults, they're computed fresh every cycle).
const FAULT_SOURCES = ["wp21i", "wp22i", "wp23i", "wp24i", "wp25i", "wp26i", "wp2tm"];

// Builds one new, blank ".fault-row" element (same markup as the row
// already in the page template) for "+ Add another fault row" to append.
function buildFaultRow() {
  const row = document.createElement("div");
  row.className = "fault-row";
  const options = FAULT_SOURCES.map((s) => `<option value="${s}">${s}</option>`).join("");
  row.innerHTML = `
    <label>source <select data-fault-field="source">${options}</select></label>
    <label>message <input type="text" data-fault-field="message" value="sensor_timeout_test"></label>
    <button type="button" class="remove-fault-row-btn btn-secondary" title="Remove this row">&times;</button>
  `;
  return row;
}

// Only show a row's own remove button once there's more than one row --
// at least one row must always remain, since "Add fault(s)" needs
// something to send.
function refreshFaultRowRemoveButtons() {
  const rows = document.querySelectorAll("#faultRows .fault-row");
  rows.forEach((row) => {
    row.querySelector(".remove-fault-row-btn").style.visibility = rows.length > 1 ? "visible" : "hidden";
  });
}

function wireFaultCard() {
  const topic = "bus/test/fault";
  const statusEl = document.getElementById("faultStatus");
  const rowsContainer = document.getElementById("faultRows");

  refreshFaultRowRemoveButtons();

  document.getElementById("addFaultRowBtn").addEventListener("click", () => {
    rowsContainer.appendChild(buildFaultRow());
    refreshFaultRowRemoveButtons();
  });

  // One delegated listener on the container handles every row's remove
  // button, including ones added later by buildFaultRow() above.
  rowsContainer.addEventListener("click", (e) => {
    if (!e.target.classList.contains("remove-fault-row-btn")) return;
    if (document.querySelectorAll("#faultRows .fault-row").length <= 1) return;
    e.target.closest(".fault-row").remove();
    refreshFaultRowRemoveButtons();
  });

  document.getElementById("addFaultBtn").addEventListener("click", async () => {
    const faults = Array.from(rowsContainer.querySelectorAll(".fault-row")).map((row) => ({
      source: row.querySelector('[data-fault-field="source"]').value,
      message: row.querySelector('[data-fault-field="message"]').value,
    }));
    statusEl.textContent = "Sending...";
    statusEl.className = "node-status muted";
    try {
      await publish(topic, { action: "add", faults });
      statusEl.textContent = `${faults.length} fault(s) added @ ` + new Date().toLocaleTimeString();
      statusEl.className = "node-status success";
    } catch (e) {
      statusEl.textContent = "Failed: " + e.message;
      statusEl.className = "node-status error";
    }
  });

  document.getElementById("clearFaultsBtn").addEventListener("click", async () => {
    statusEl.textContent = "Clearing...";
    statusEl.className = "node-status muted";
    try {
      await publish(topic, { action: "clear" });
      statusEl.textContent = "All injected faults cleared @ " + new Date().toLocaleTimeString();
      statusEl.className = "node-status success";
    } catch (e) {
      statusEl.textContent = "Failed: " + e.message;
      statusEl.className = "node-status error";
    }
  });
}

wireIndividualSendButtons();
wireDummy2Toggle();
wireSendAll();
wireCanOverrideCard();
wireFaultCard();
refreshConnectionIndicator();
setInterval(refreshConnectionIndicator, 5000);
