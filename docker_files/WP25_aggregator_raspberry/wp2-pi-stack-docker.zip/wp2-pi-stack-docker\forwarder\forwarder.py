"""
Forwards this bus's own combined records to the central fleet broker over
TLS, under fleet/{VEHICLE_ID}/unified/combined.

Reads the LOCAL wp2_records table directly (same DB the aggregator already
writes to) instead of subscribing to the local MQTT topic. This matters:
an MQTT-subscribe-and-republish bridge is fire-and-forget -- if the link to
the central broker is down (an LTE outage), paho-mqtt's publish() fails
immediately (MQTT_ERR_NO_CONN) and does not queue the message, so anything
published while disconnected is silently lost. That was verified directly
against this stack: a 10s central-broker outage produced an exact 10s gap
in the central table.

Polling wp2_records' pre-existing "forwarded" column instead makes the
local Postgres row itself the durable queue: a row is only marked
forwarded=true after the central broker has acknowledged the QoS 1
publish, so an outage of any length (LTE dead zone, central maintenance)
just means the backlog gets sent once connectivity returns -- nothing is
lost as long as local disk isn't.

Does not touch the aggregator or its inserts -- purely reads/updates the
"forwarded" flag on rows it has successfully relayed.
"""

import json
import os
import time

import paho.mqtt.client as mqtt
import psycopg2
import psycopg2.extras

DB_HOST = os.environ.get("DB_HOST", "timescaledb")
DB_PORT = int(os.environ.get("DB_PORT", 5432))
DB_NAME = os.environ.get("DB_NAME", "wp2data")
DB_USER = os.environ.get("DB_USER", "wp2user")
DB_PASSWORD = os.environ.get("DB_PASSWORD", "")

VEHICLE_ID = os.environ.get("VEHICLE_ID", "BUS_2034")

CENTRAL_MQTT_HOST = os.environ["CENTRAL_MQTT_HOST"]
CENTRAL_MQTT_PORT = int(os.environ.get("CENTRAL_MQTT_PORT", 8883))
CENTRAL_MQTT_USERNAME = os.environ.get("CENTRAL_MQTT_USERNAME", VEHICLE_ID)
CENTRAL_MQTT_PASSWORD = os.environ["CENTRAL_MQTT_PASSWORD"]
CENTRAL_CA_CERT = os.environ.get("CENTRAL_CA_CERT", "/certs/ca.crt")
CENTRAL_TOPIC = f"fleet/{VEHICLE_ID}/unified/combined"

POLL_INTERVAL_SEC = float(os.environ.get("POLL_INTERVAL_SEC", 1.0))
BATCH_SIZE = int(os.environ.get("BATCH_SIZE", 100))
PUBLISH_ACK_TIMEOUT_SEC = 5.0


def get_db_connection():
    return psycopg2.connect(
        host=DB_HOST, port=DB_PORT, dbname=DB_NAME, user=DB_USER, password=DB_PASSWORD
    )


def build_central_client():
    client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=f"{VEHICLE_ID}-forwarder")
    client.username_pw_set(CENTRAL_MQTT_USERNAME, CENTRAL_MQTT_PASSWORD)
    client.tls_set(ca_certs=CENTRAL_CA_CERT)
    client.reconnect_delay_set(min_delay=1, max_delay=30)

    def on_connect(c, userdata, flags, reason_code, properties=None):
        print(f"[CENTRAL] Connected (reason_code={reason_code}).")

    def on_disconnect(c, userdata, flags, reason_code, properties=None):
        print(f"[CENTRAL] Disconnected (reason_code={reason_code}); backlog will build up in wp2_records until reconnect.")

    client.on_connect = on_connect
    client.on_disconnect = on_disconnect
    return client


def forward_backlog(conn, client):
    with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
        cur.execute(
            'SELECT "time", vehicle_id, trip_id, payload FROM wp2_records '
            'WHERE forwarded = false ORDER BY "time" LIMIT %s',
            (BATCH_SIZE,),
        )
        rows = cur.fetchall()

    if not rows:
        return 0

    if not client.is_connected():
        return 0

    sent = 0
    for row in rows:
        payload = row["payload"]
        info = client.publish(CENTRAL_TOPIC, json.dumps(payload), qos=1)
        info.wait_for_publish(timeout=PUBLISH_ACK_TIMEOUT_SEC)
        if not info.is_published():
            print(f"[FORWARDER] Publish not acked for row @ {row['time']}, will retry next cycle.")
            break

        with conn.cursor() as cur:
            cur.execute(
                'UPDATE wp2_records SET forwarded = true WHERE "time" = %s AND vehicle_id = %s',
                (row["time"], row["vehicle_id"]),
            )
        conn.commit()
        sent += 1

    return sent


def main():
    print(f"[FORWARDER] Starting DB-backed forwarder for {VEHICLE_ID} -> {CENTRAL_MQTT_HOST}:{CENTRAL_MQTT_PORT}")

    conn = None
    for attempt in range(30):
        try:
            conn = get_db_connection()
            print("[DB] Connected to local TimescaleDB.")
            break
        except psycopg2.OperationalError as e:
            print(f"[DB] Not ready yet ({e}); retrying in 2s... ({attempt + 1}/30)")
            time.sleep(2)
    if conn is None:
        raise RuntimeError("Could not connect to local TimescaleDB after 30 attempts.")

    client = build_central_client()
    try:
        client.connect(CENTRAL_MQTT_HOST, CENTRAL_MQTT_PORT, keepalive=60)
    except (ConnectionRefusedError, OSError) as e:
        print(f"[CENTRAL] Broker not reachable yet ({e}); will keep retrying via loop_start().")
    client.loop_start()

    while True:
        try:
            sent = forward_backlog(conn, client)
            if sent:
                print(f"[FORWARDER] Forwarded {sent} row(s).")
        except psycopg2.Error as e:
            print(f"[DB] Error while forwarding backlog: {e}")
            conn.rollback()
        time.sleep(POLL_INTERVAL_SEC)


if __name__ == "__main__":
    main()
