// WP2.5.i sensor emulator -- front-end logic.
//
// Two kinds of sections in the page:
//   - ".node-card" -- simulates a real WP2.x sensor/thermal-manikin node.
//     Clicking its "Send" button builds a JSON payload from that card's
//     own inputs (shape depends on the card's data-shape attribute -- see
//     buildPayload() below) and POSTs it to this server's /publish
//     endpoint, which republishes it on the local MQTT broker exactly as
//     if that node had sent it. These are also what "Send all enabled
//     sensor sections" (below) sends.
//   - ".test-card" -- the two test-only injection controls (CAN/energy
//     override, fault injection). These are deliberately NOT part of
//     "Send all", since they aren't simulated sensors -- they have their
//     own dedicated buttons instead (see wireCanOverrideCard() /
//     wireFaultCard() below).

// Poll /health periodically and show whether the emulator's own MQTT
// client is currently connected to the local broker -- if it isn't,
// every "Send" click below would just fail with a clear 503, but showing
// this up front avoids the confusion of "why did my click do nothing".
async function refreshConnectionIndicator() {
  const indicator = document.getElementById("connIndicator");
  try {
    const res = await fetch("/health");
    const data = await res.json();
    if (data.mqtt_connected) {
      indicator.textContent = "broker: connected";
      indicator.className = "conn-indicator conn-ok";
    } else {
      indicator.textContent = "broker: not connected";
      indicator.className = "conn-indicator conn-bad";
    }
  } catch (e) {
    indicator.textContent = "broker: unknown (page offline?)";
    indicator.className = "conn-indicator conn-bad";
  }
}

// Reads a single [data-field] input's value, honoring data-field-type:
//   "bool" (a checkbox)         -> true/false
//   (anything else, default)   -> parsed as a float, or null if blank
function readFieldValue(input) {
  if (input.dataset.fieldType === "bool") {
    return input.checked;
  }
  const raw = input.value;
  return raw === "" ? null : parseFloat(raw);
}

// Reads every direct (non-nested) "[data-field]" input inside a container
// and returns a flat object of {fieldName: value}. Used for cards whose
// data-field names have no "." in them -- WP2.1.i/WP2.2.i/WP2.3.i nodes,
// WP2.TM, and the CAN/energy override card, all of which map to a flat
// object in WP2_payload_schema.json (no nested sub-objects).
function readFlatFields(container) {
  const fields = {};
  container.querySelectorAll("[data-field]").forEach((input) => {
    fields[input.dataset.field] = readFieldValue(input);
  });
  return fields;
}

// Reads every "[data-field]" input inside a container whose data-field is
// written as "group.field" (e.g. "head.temp_c") and rebuilds the nested
// object WP2_payload_schema.json's thermal_dummy_wp26N.surface expects --
// {head: {temp_c: ...}, neck: {...}, ...}. Every thermal-dummy field is
// dotted like this; there are no bare (non-nested) fields in that card.
function readNestedSurfaceFields(container) {
  const surface = {};
  container.querySelectorAll("[data-field]").forEach((input) => {
    const [group, field] = input.dataset.field.split(".");
    if (!surface[group]) surface[group] = {};
    surface[group][field] = readFieldValue(input);
  });
  return surface;
}

// Builds the exact JSON payload aggregator.py expects for a given
// ".node-card", based on its data-shape attribute:
//   (none)            -> the fields themselves, flat, e.g.
//                         {c1_temp_C_head_standing: 23.4, ...}
//                         (matches WP2.1.i/WP2.2.i/WP2.3.i, which
//                         aggregator.py's TOPIC_MAP stores verbatim under
//                         bus_environment.<group>.<node>)
//   "thermal_dummy"   -> {"thermal_dummy": {"surface": {...nested...}}}
//                         (matches on_message()'s handling of
//                         THERMAL_DUMMY_TOPICS -- any of the 3 dummies)
//   "wp2tm"           -> {"internal_wp2tm": {...32 flat fields...}}
//                         (matches on_message()'s handling of
//                         WP2TM_TOPICS -- any of the 3 manikins)
function buildPayload(card) {
  const shape = card.dataset.shape;

  if (shape === "thermal_dummy") {
    return { thermal_dummy: { surface: readNestedSurfaceFields(card) } };
  }
  if (shape === "wp2tm") {
    return { internal_wp2tm: readFlatFields(card) };
  }
  return readFlatFields(card);
}

// Publishes {topic, payload} to /publish and returns the parsed response,
// throwing an Error with a human-readable message on any failure. Shared
// by both node-card sending (sendCard() below) and the two dedicated
// test-card controls (CAN override, fault injection), so all three report
// errors (broker down, bad topic, timeout) the same way.
async function publish(topic, payload) {
  const res = await fetch("/publish", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ topic, payload }),
  });
  if (res.ok) return res.json();
  const body = await res.json().catch(() => ({}));
  throw new Error(body.detail || String(res.status));
}

// Sends one node-card's payload to /publish and updates that card's own
// status text in place. Returns true on success, false on failure, so
// "Send all" (below) can report how many succeeded.
async function sendCard(card) {
  const statusEl = card.querySelector(".node-status");
  const topic = card.dataset.topic;

  statusEl.textContent = "Sending...";
  statusEl.className = "node-status muted";

  try {
    await publish(topic, buildPayload(card));
    statusEl.textContent = "Sent @ " + new Date().toLocaleTimeString();
    statusEl.className = "node-status success";
    return true;
  } catch (e) {
    statusEl.textContent = "Failed: " + e.message;
    statusEl.className = "node-status error";
    return false;
  }
}

function wireIndividualSendButtons() {
  document.querySelectorAll(".node-card").forEach((card) => {
    const btn = card.querySelector(".send-node-btn");
    btn.addEventListener("click", () => sendCard(card));
  });
}

// "Send all enabled sensor sections now": every ".node-card" gets sent,
// one after another, and the toolbar shows a simple success/failure count
// once they're all done. Deliberately excludes the two ".test-card"
// controls (CAN override, fault injection) -- those aren't simulated
// sensors, and are sent independently via their own buttons (see
// wireCanOverrideCard() / wireFaultCard()). Unlike an earlier version of
// this tool, there's no "disabled until enabled" card to skip here -- all
// 3 thermal dummies are always sendable, since "active" is computed by
// aggregator.py from message recency, not declared by this UI (see
// THERMAL_DUMMY_ACTIVE_TIMEOUT_SEC in aggregator.py).
function wireSendAll() {
  document.getElementById("sendAllBtn").addEventListener("click", async () => {
    const statusEl = document.getElementById("globalStatus");
    const cards = Array.from(document.querySelectorAll(".node-card"));
    statusEl.textContent = `Sending ${cards.length} section(s)...`;

    let succeeded = 0;
    for (const card of cards) {
      if (await sendCard(card)) succeeded += 1;
    }

    statusEl.textContent = `Done: ${succeeded}/${cards.length} sent successfully.`;
  });
}

// --- Thermal dummy (WP2.6.i) + internal WP2.TM card rendering ------------
// There are 3 of each (see WP2_payload_schema.json's "thermal_dummies"
// object) and every instance's fields are identical -- only the topic
// number changes -- so the markup is generated from these two data
// structures instead of repeating ~50-90 lines of near-identical HTML by
// hand 3 times over (error-prone to keep in sync, e.g. a typo'd field name
// on only one copy).

// The 7 body-region groups making up one thermal dummy's "surface" object.
// Each entry is [fieldName, defaultValue]; region field order here is the
// display order, and matches WP2_payload_schema.json's field names exactly.
const SURFACE_REGIONS = [
  { name: "head", fields: [
    ["temp_c", 31.5], ["rh_percent", 60], ["iav_m_per_s_x", 2.3], ["iav_m_per_s_y", 2.3], ["globe_temp_c", 31.5],
  ] },
  { name: "neck", fields: [
    ["temp_c", 31.5], ["iav_m_per_s_x", 2.3], ["iav_m_per_s_y", 2.3],
  ] },
  { name: "torso", fields: [
    ["temp_c", 31.5], ["globe_temp_c", 31.5],
  ] },
  { name: "abdomen", fields: [
    ["temp_c", 31.5],
  ] },
  { name: "arms", fields: [
    ["temp_c_left_upper_arm", 31.5], ["temp_c_right_upper_arm", 31.5],
    ["temp_c_left_forearm", 31.5], ["temp_c_right_forearm", 31.5],
    ["temp_c_left_hand", 31.5], ["temp_c_right_hand", 31.5],
  ] },
  { name: "legs", fields: [
    ["temp_c_left_thigh", 31.5], ["temp_c_right_thigh", 31.5],
    ["temp_c_left_calf", 31.5], ["temp_c_right_calf", 31.5],
    ["temp_c_left_foot", 31.5], ["temp_c_right_foot", 31.5],
    ["globe_temp_c_feet", 31.5], ["iav_m_per_s_x_feet", 2.3], ["iav_m_per_s_y_feet", 2.3],
  ] },
  { name: "auxiliary", fields: [
    ["cushion_temp_c", 31.5], ["iav_m_per_s_aux_z1", 2.3], ["iav_m_per_s_aux_z2", 2.3],
  ] },
];

// The 16 body zones making up one internal_wp2tmN object -- each a
// [temp field, its own on_status_pad_* boolean field] pair, flat (no
// nesting), exactly matching WP2_payload_schema.json.
const WP2TM_ZONES = [
  ["temp_head", "on_status_pad_head"],
  ["temp_chest_left", "on_status_pad_chest_left"],
  ["temp_chest_right", "on_status_pad_chest_right"],
  ["temp_abdomen", "on_status_pad_abdomen"],
  ["temp_tight_left", "on_status_pad_tight_left"],
  ["temp_tight_right", "on_status_pad_tight_right"],
  ["temp_upper_left_arm", "on_status_pad_upper_left_arm"],
  ["temp_upper_right_arm", "on_status_pad_upper_right_arm"],
  ["temp_lower_left_arm", "on_status_pad_lower_left_arm"],
  ["temp_lower_right_arm", "on_status_pad_lower_right_arm"],
  ["temp_left_hand", "on_status_pad_left_hand"],
  ["temp_right_hand", "on_status_pad_right_hand"],
  ["temp_lower_left_leg", "on_status_pad_lower_left_leg"],
  ["temp_lower_right_leg", "on_status_pad_lower_right_leg"],
  ["temp_left_foot", "on_status_pad_left_foot"],
  ["temp_right_foot", "on_status_pad_right_foot"],
];

// Builds one thermal-dummy ".node-card" (n = 1, 2, or 3), publishing to
// bus/env/thermal_dummy_<n> -- see THERMAL_DUMMY_TOPICS in aggregator.py.
function renderThermalDummyCard(n) {
  const card = document.createElement("div");
  card.className = "node-card node-card-wide";
  card.dataset.topic = `bus/env/thermal_dummy_${n}`;
  card.dataset.shape = "thermal_dummy";

  const groupsHtml = SURFACE_REGIONS.map((region) => {
    const fieldsHtml = region.fields
      .map(([field, def]) => `<label>${field} <input type="number" step="0.1" value="${def}" data-field="${region.name}.${field}"></label>`)
      .join("");
    return `<fieldset><legend>${region.name}</legend>${fieldsHtml}</fieldset>`;
  }).join("");

  card.innerHTML = `
    <h3>Dummy #${n}</h3>
    <div class="surface-groups">${groupsHtml}</div>
    <button type="button" class="send-node-btn">Send</button>
    <span class="node-status muted"></span>
  `;
  return card;
}

// Builds one internal-WP2.TM ".node-card" (n = 1, 2, or 3), publishing to
// bus/env/wp2tm_<n> -- see WP2TM_TOPICS in aggregator.py.
function renderWp2tmCard(n) {
  const card = document.createElement("div");
  card.className = "node-card node-card-wide";
  card.dataset.topic = `bus/env/wp2tm_${n}`;
  card.dataset.shape = "wp2tm";

  const zonesHtml = WP2TM_ZONES
    .map(([tempField, statusField]) => `
      <div class="wp2tm-zone">
        <label>${tempField} <input type="number" step="0.1" value="35.8" data-field="${tempField}"></label>
        <label class="inline-toggle"><input type="checkbox" checked data-field="${statusField}" data-field-type="bool"> ${statusField}</label>
      </div>
    `)
    .join("");

  card.innerHTML = `
    <div class="wp2tm-grid">${zonesHtml}</div>
    <button type="button" class="send-node-btn">Send</button>
    <span class="node-status muted"></span>
  `;
  return card;
}

// Populates #thermalDummyCards and #wp2tmCards with 3 cards each. Must run
// before wireIndividualSendButtons()/wireSendAll() below, since those
// query for ".node-card"/".send-node-btn" elements that don't exist until
// this has run.
function renderThermalAndWp2tmCards() {
  const dummyContainer = document.getElementById("thermalDummyCards");
  const wp2tmContainer = document.getElementById("wp2tmCards");
  for (let n = 1; n <= 3; n++) {
    dummyContainer.appendChild(renderThermalDummyCard(n));
    wp2tmContainer.appendChild(renderWp2tmCard(n));
  }
}

// Energy/CAN override test control (bus/test/can_override). "Set
// override" publishes the 8 wp25i-shaped fields as-is (no wrapper object
// -- aggregator.py's on_message() stores whatever's published here
// directly as the module-level can_override). "Clear override" publishes
// an empty object, which on_message() treats as falsy and reverts
// get_can_data() to its normal real-hardware/stub behavior.
function wireCanOverrideCard() {
  const card = document.getElementById("canOverrideCard");
  const statusEl = document.getElementById("overrideStatus");
  const topic = card.dataset.topic;

  document.getElementById("setOverrideBtn").addEventListener("click", async () => {
    statusEl.textContent = "Sending...";
    statusEl.className = "node-status muted";
    try {
      await publish(topic, readFlatFields(card));
      statusEl.textContent = "Override set @ " + new Date().toLocaleTimeString();
      statusEl.className = "node-status success";
    } catch (e) {
      statusEl.textContent = "Failed: " + e.message;
      statusEl.className = "node-status error";
    }
  });

  document.getElementById("clearOverrideBtn").addEventListener("click", async () => {
    statusEl.textContent = "Clearing...";
    statusEl.className = "node-status muted";
    try {
      await publish(topic, {});
      statusEl.textContent = "Override cleared @ " + new Date().toLocaleTimeString();
      statusEl.className = "node-status success";
    } catch (e) {
      statusEl.textContent = "Failed: " + e.message;
      statusEl.className = "node-status error";
    }
  });
}

// Fault-injection test control (bus/test/fault). #faultRows holds one or
// more ".fault-row" elements, each a {source, message} pair; "Add
// fault(s)" always collects every current row and publishes them all in
// a single message -- {"action": "add", "faults": [...]}} -- which
// aggregator.py's on_message() appends to the module-level sensor_faults
// list in one go (see the FAULT_TOPIC comment in aggregator.py). This
// means several simulated faults can land in the very same aggregation
// cycle instead of needing one publish (and one MQTT round-trip) per
// fault. "Clear all injected faults" publishes {"action": "clear"},
// emptying that list (this does NOT clear the auto-appended
// no_can_hardware/no_gps_hardware entries build_unified_record() adds
// itself when that hardware is genuinely absent -- those aren't stored in
// sensor_faults, they're computed fresh every cycle).
const FAULT_SOURCES = [
  "wp21i", "wp22i", "wp23i", "wp24i", "wp25i",
  "wp26i_1", "wp26i_2", "wp26i_3", "wp2tm_1", "wp2tm_2", "wp2tm_3",
];

// Builds one new, blank ".fault-row" element (same markup as the row
// already in the page template) for "+ Add another fault row" to append.
function buildFaultRow() {
  const row = document.createElement("div");
  row.className = "fault-row";
  const options = FAULT_SOURCES.map((s) => `<option value="${s}">${s}</option>`).join("");
  row.innerHTML = `
    <label>source <select data-fault-field="source">${options}</select></label>
    <label>message <input type="text" data-fault-field="message" value="sensor_timeout_test"></label>
    <button type="button" class="remove-fault-row-btn btn-secondary" title="Remove this row">&times;</button>
  `;
  return row;
}

// Only show a row's own remove button once there's more than one row --
// at least one row must always remain, since "Add fault(s)" needs
// something to send.
function refreshFaultRowRemoveButtons() {
  const rows = document.querySelectorAll("#faultRows .fault-row");
  rows.forEach((row) => {
    row.querySelector(".remove-fault-row-btn").style.visibility = rows.length > 1 ? "visible" : "hidden";
  });
}

function wireFaultCard() {
  const topic = "bus/test/fault";
  const statusEl = document.getElementById("faultStatus");
  const rowsContainer = document.getElementById("faultRows");

  refreshFaultRowRemoveButtons();

  document.getElementById("addFaultRowBtn").addEventListener("click", () => {
    rowsContainer.appendChild(buildFaultRow());
    refreshFaultRowRemoveButtons();
  });

  // One delegated listener on the container handles every row's remove
  // button, including ones added later by buildFaultRow() above.
  rowsContainer.addEventListener("click", (e) => {
    if (!e.target.classList.contains("remove-fault-row-btn")) return;
    if (document.querySelectorAll("#faultRows .fault-row").length <= 1) return;
    e.target.closest(".fault-row").remove();
    refreshFaultRowRemoveButtons();
  });

  document.getElementById("addFaultBtn").addEventListener("click", async () => {
    const faults = Array.from(rowsContainer.querySelectorAll(".fault-row")).map((row) => ({
      source: row.querySelector('[data-fault-field="source"]').value,
      message: row.querySelector('[data-fault-field="message"]').value,
    }));
    statusEl.textContent = "Sending...";
    statusEl.className = "node-status muted";
    try {
      await publish(topic, { action: "add", faults });
      statusEl.textContent = `${faults.length} fault(s) added @ ` + new Date().toLocaleTimeString();
      statusEl.className = "node-status success";
    } catch (e) {
      statusEl.textContent = "Failed: " + e.message;
      statusEl.className = "node-status error";
    }
  });

  document.getElementById("clearFaultsBtn").addEventListener("click", async () => {
    statusEl.textContent = "Clearing...";
    statusEl.className = "node-status muted";
    try {
      await publish(topic, { action: "clear" });
      statusEl.textContent = "All injected faults cleared @ " + new Date().toLocaleTimeString();
      statusEl.className = "node-status success";
    } catch (e) {
      statusEl.textContent = "Failed: " + e.message;
      statusEl.className = "node-status error";
    }
  });
}

renderThermalAndWp2tmCards();
wireIndividualSendButtons();
wireSendAll();
wireCanOverrideCard();
wireFaultCard();
refreshConnectionIndicator();
setInterval(refreshConnectionIndicator, 5000);
