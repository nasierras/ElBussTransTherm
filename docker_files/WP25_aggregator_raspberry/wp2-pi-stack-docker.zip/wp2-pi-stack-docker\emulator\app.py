"""
WP2.5.i -- Sensor emulator.

A small standalone web tool for manually testing the data pipeline without
needing real ESP32/CAN/GPS hardware attached. It does exactly one thing:
publish a hand-crafted MQTT message to the LOCAL Mosquitto broker on this
Pi, on whichever topic you choose, with whatever payload the form builds.
From there, the existing aggregator picks it up exactly as if a real
sensor node had sent it -- merges it into the next combined record, writes
it to the local database, and the forwarder relays it to the central
fleet broker on its next cycle. This tool never talks to the database or
the central broker directly; it only ever publishes to the local broker,
the same way a real ESP32 node (or the CAN/fault test-injection paths in
aggregator.py) would.

Every field in the form is named after WP2_payload_schema.json exactly --
that file is the single source of truth for this tool's shape, not the
other way around. Two kinds of topics are supported:
  - "bus/env/..." -- real sensor-shaped data (WP2.1.i/2.2.i/2.3.i,
    the thermal dummies, WP2.TM), picked up by aggregator.py's normal
    MQTT subscription exactly like a real ESP32 node's traffic.
  - "bus/test/..." -- the two test-only injection topics aggregator.py
    also understands: bus/test/can_override (dummy wp25i energy data,
    since there is no DBC file yet) and bus/test/fault (simulated
    diagnostics.sensor_faults entries, since no real fault-detection
    logic exists yet either).

Runs as its own container (see docker-compose.yml) on the same Docker
network as the "mosquitto" service, so it can reach it by service name
exactly like the aggregator does.
"""

import json
import os
import threading
import time
from contextlib import asynccontextmanager

import paho.mqtt.client as mqtt
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel

# Same defaults as aggregator.py -- this tool publishes to the same local
# broker the aggregator subscribes to, so it needs to resolve it the same
# way (by Docker Compose service name, "mosquitto", on the shared network).
MQTT_BROKER = os.environ.get("MQTT_BROKER", "mosquitto")
MQTT_PORT = int(os.environ.get("MQTT_PORT", 1883))

# Directory containing this file, used below to locate templates/static
# regardless of the container's current working directory.
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

templates = Jinja2Templates(directory=os.path.join(BASE_DIR, "templates"))


class PublishRequest(BaseModel):
    """Request body for POST /publish -- an MQTT topic and a JSON-serializable payload to send on it."""

    topic: str
    payload: dict


# --------------------------------------------------------------------------
# MQTT client setup
# --------------------------------------------------------------------------
# A single, persistent paho-mqtt client shared across all requests, kept
# connected in the background exactly like the aggregator's and
# forwarder's own MQTT clients. Connecting fresh on every button click
# would work too, but would add real latency (and a visible delay) to
# every single "Send" click for no benefit -- this tool is meant to feel
# instant when testing.
mqtt_client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)

# True only while the client is actually connected to the broker. The
# /publish endpoint checks this before attempting to publish, so it can
# return a clear error instead of silently dropping a message if the
# broker connection is currently down.
mqtt_connected = False
mqtt_lock = threading.Lock()


def _on_connect(client, userdata, flags, reason_code, properties=None):
    global mqtt_connected
    with mqtt_lock:
        mqtt_connected = True
    print(f"[EMULATOR] Connected to local broker (reason_code={reason_code}).")


def _on_disconnect(client, userdata, flags, reason_code, properties=None):
    global mqtt_connected
    with mqtt_lock:
        mqtt_connected = False
    print(f"[EMULATOR] Disconnected from local broker (reason_code={reason_code}).")


mqtt_client.on_connect = _on_connect
mqtt_client.on_disconnect = _on_disconnect


def _mqtt_connect_loop():
    """
    Runs once in a background thread at startup. Retries connecting to the
    local broker forever (same pattern used everywhere else in this
    project) so a slow-starting Mosquitto container never crashes this
    tool -- it just isn't able to publish yet, which /publish reports
    clearly via mqtt_connected.
    """
    while True:
        try:
            mqtt_client.connect(MQTT_BROKER, MQTT_PORT, keepalive=30)
            mqtt_client.loop_start()
            return
        except (ConnectionRefusedError, OSError) as e:
            print(f"[EMULATOR] Broker not ready yet ({e}); retrying in 2s...")
            time.sleep(2)


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Start the background MQTT connect/retry loop once, when the app
    # starts, and just let it keep running for the process's whole
    # lifetime -- there is nothing to clean up on shutdown here, since
    # paho-mqtt's own background network thread (started once connected)
    # stops on its own when the process exits.
    threading.Thread(target=_mqtt_connect_loop, daemon=True).start()
    yield


app = FastAPI(title="WP2.5.i Sensor Emulator", lifespan=lifespan)
app.mount("/static", StaticFiles(directory=os.path.join(BASE_DIR, "static")), name="static")


@app.get("/")
def index(request: Request):
    """Serves the emulator form. All rendering/interactivity lives in the template's own JS -- this route just returns the page shell."""
    return templates.TemplateResponse(request, "index.html", {})


@app.get("/health")
def health():
    """Simple liveness/readiness probe, also used by the page itself to show a connection indicator."""
    with mqtt_lock:
        connected = mqtt_connected
    return {"mqtt_connected": connected}


@app.post("/publish")
def publish(body: PublishRequest):
    """
    Publishes body.payload (JSON-encoded) to body.topic on the local
    broker, QoS 1 -- matching exactly how a real ESP32 node, or the
    aggregator's own republish, sends messages elsewhere in this project.
    Returns 503 if the broker connection isn't currently up, rather than
    silently losing the message or hanging.
    """
    with mqtt_lock:
        connected = mqtt_connected
    if not connected:
        raise HTTPException(status_code=503, detail="Not connected to the local MQTT broker yet.")

    if not (body.topic.startswith("bus/env/") or body.topic.startswith("bus/test/")):
        # Not a hard technical requirement -- paho-mqtt would happily
        # publish to any topic -- but every topic this tool is meant to
        # simulate is either a real "bus/env/..." sensor topic (see
        # aggregator.py's TOPIC_MAP) or one of the two "bus/test/..."
        # test-injection topics (CAN_OVERRIDE_TOPIC, FAULT_TOPIC) it also
        # understands, so catching a typo'd topic here early is more useful
        # than letting it silently vanish into a topic nothing subscribes to.
        raise HTTPException(
            status_code=400,
            detail="Topic must start with 'bus/env/' or 'bus/test/' to be picked up by the aggregator.",
        )

    result = mqtt_client.publish(body.topic, json.dumps(body.payload), qos=1)
    # wait_for_publish blocks until the QoS 1 broker acknowledgment comes
    # back, so a 200 response here means the broker actually has the
    # message, not just that we handed it to the local socket buffer.
    result.wait_for_publish(timeout=5.0)
    if not result.is_published():
        raise HTTPException(status_code=502, detail="Broker did not acknowledge the publish in time.")

    return JSONResponse({"ok": True, "topic": body.topic})
