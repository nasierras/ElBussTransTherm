#!/bin/bash
# Runs once, automatically, only when the timescaledb container starts with an
# empty data volume (standard docker-entrypoint-initdb.d behavior).
set -e

psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" <<-EOSQL
    CREATE EXTENSION IF NOT EXISTS timescaledb;

    CREATE TABLE IF NOT EXISTS wp2_records (
        "time"      timestamptz NOT NULL DEFAULT now(),
        vehicle_id  text,
        trip_id     integer,
        forwarded   boolean NOT NULL DEFAULT false,
        payload     jsonb NOT NULL
    );

    SELECT create_hypertable('wp2_records', 'time', if_not_exists => TRUE);

    CREATE INDEX IF NOT EXISTS wp2_records_time_idx
        ON wp2_records USING btree ("time" DESC);
    CREATE INDEX IF NOT EXISTS idx_wp2_records_forwarded
        ON wp2_records USING btree (forwarded) WHERE (forwarded = false);

    DO \$\$
    BEGIN
        IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = '${WP2_DB_USER}') THEN
            CREATE ROLE "${WP2_DB_USER}" WITH LOGIN PASSWORD '${WP2_DB_PASSWORD}';
        END IF;
    END
    \$\$;

    -- These three grants are required in addition to "CREATE DATABASE ... OWNER wp2user";
    -- ownership of the database does NOT automatically grant privileges on tables
    -- created by the postgres superuser, and this was the exact issue hit on the
    -- original bare-metal deployment ("permission denied for table wp2_records").
    GRANT ALL PRIVILEGES ON TABLE wp2_records TO "${WP2_DB_USER}";
    GRANT USAGE ON SCHEMA public TO "${WP2_DB_USER}";
    ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO "${WP2_DB_USER}";
EOSQL
