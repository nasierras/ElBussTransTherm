#!/bin/bash
# Runs once, automatically, only when the timescaledb container starts with an
# empty data volume (standard docker-entrypoint-initdb.d behavior).
set -e

psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" <<-EOSQL
    CREATE EXTENSION IF NOT EXISTS timescaledb;

    CREATE TABLE IF NOT EXISTS buses (
        id           serial PRIMARY KEY,
        vehicle_id   text NOT NULL UNIQUE,
        display_name text,
        is_active    boolean NOT NULL DEFAULT true,
        created_at   timestamptz NOT NULL DEFAULT now()
    );

    CREATE TABLE IF NOT EXISTS app_users (
        id            serial PRIMARY KEY,
        username      text NOT NULL UNIQUE,
        password_hash text NOT NULL,
        role          text NOT NULL CHECK (role IN ('admin', 'user')),
        is_active     boolean NOT NULL DEFAULT true,
        created_at    timestamptz NOT NULL DEFAULT now(),
        password_changed_at timestamptz NOT NULL DEFAULT now()
    );

    CREATE TABLE IF NOT EXISTS user_bus_assignments (
        user_id  integer NOT NULL REFERENCES app_users(id) ON DELETE CASCADE,
        bus_id   integer NOT NULL REFERENCES buses(id) ON DELETE CASCADE,
        PRIMARY KEY (user_id, bus_id)
    );

    CREATE TABLE IF NOT EXISTS fleet_events (
        "time"      timestamptz NOT NULL DEFAULT now(),
        vehicle_id  text NOT NULL,
        trip_id     integer,
        payload     jsonb NOT NULL
    );

    SELECT create_hypertable('fleet_events', 'time', if_not_exists => TRUE);

    CREATE INDEX IF NOT EXISTS fleet_events_vehicle_time_idx
        ON fleet_events (vehicle_id, "time" DESC);

    DO \$\$
    BEGIN
        IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = '${FLEET_DB_USER}') THEN
            CREATE ROLE "${FLEET_DB_USER}" WITH LOGIN PASSWORD '${FLEET_DB_PASSWORD}';
        END IF;
    END
    \$\$;

    GRANT ALL PRIVILEGES ON TABLE buses, app_users, user_bus_assignments, fleet_events TO "${FLEET_DB_USER}";
    GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO "${FLEET_DB_USER}";
    GRANT USAGE ON SCHEMA public TO "${FLEET_DB_USER}";
    ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL ON TABLES TO "${FLEET_DB_USER}";
EOSQL
