from sqlalchemy import (
    Boolean,
    CheckConstraint,
    Column,
    DateTime,
    ForeignKey,
    Integer,
    String,
    func,
)

from .database import Base


class AppUser(Base):
    __tablename__ = "app_users"

    id = Column(Integer, primary_key=True)
    username = Column(String, unique=True, nullable=False)
    password_hash = Column(String, nullable=False)
    role = Column(String, nullable=False)
    is_active = Column(Boolean, nullable=False, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    password_changed_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)

    __table_args__ = (CheckConstraint("role IN ('admin','user')", name="app_users_role_check"),)


class Bus(Base):
    __tablename__ = "buses"

    id = Column(Integer, primary_key=True)
    vehicle_id = Column(String, unique=True, nullable=False)
    display_name = Column(String)
    is_active = Column(Boolean, nullable=False, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class UserBusAssignment(Base):
    __tablename__ = "user_bus_assignments"

    user_id = Column(Integer, ForeignKey("app_users.id", ondelete="CASCADE"), primary_key=True)
    bus_id = Column(Integer, ForeignKey("buses.id", ondelete="CASCADE"), primary_key=True)
