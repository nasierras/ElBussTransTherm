from datetime import datetime
from typing import Optional

from pydantic import BaseModel, ConfigDict


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    username: str
    role: str
    is_active: bool


class UserCreate(BaseModel):
    username: str
    password: str
    role: str


class BusOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    vehicle_id: str
    display_name: Optional[str] = None
    is_active: bool


class BusCreate(BaseModel):
    vehicle_id: str
    display_name: Optional[str] = None


class BusCreated(BusOut):
    mqtt_username: str
    mqtt_password: str


class PasswordChange(BaseModel):
    current_password: str
    new_password: str


class PasswordReset(BaseModel):
    new_password: str


class EventOut(BaseModel):
    time: datetime
    vehicle_id: str
    trip_id: Optional[int] = None
    payload: dict
