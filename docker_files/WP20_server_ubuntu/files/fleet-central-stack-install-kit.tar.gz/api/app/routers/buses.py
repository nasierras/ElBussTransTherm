from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from .. import dynsec_client, models, schemas
from ..database import get_db
from ..deps import assigned_bus_ids, get_current_user, require_admin
from ..web.deps import csrf_guard

router = APIRouter(tags=["buses"])


@router.post(
    "/buses",
    response_model=schemas.BusCreated,
    status_code=status.HTTP_201_CREATED,
    dependencies=[Depends(csrf_guard)],
)
def create_bus(
    body: schemas.BusCreate,
    db: Session = Depends(get_db),
    _admin: models.AppUser = Depends(require_admin),
):
    existing = db.query(models.Bus).filter(models.Bus.vehicle_id == body.vehicle_id).first()
    if existing:
        raise HTTPException(status_code=409, detail="A bus with this vehicle_id already exists")

    mqtt_password = dynsec_client.create_bus_mqtt_client(body.vehicle_id)

    bus = models.Bus(vehicle_id=body.vehicle_id, display_name=body.display_name)
    db.add(bus)
    db.commit()
    db.refresh(bus)

    return schemas.BusCreated(
        id=bus.id,
        vehicle_id=bus.vehicle_id,
        display_name=bus.display_name,
        is_active=bus.is_active,
        mqtt_username=bus.vehicle_id,
        mqtt_password=mqtt_password,
    )


@router.delete(
    "/buses/{bus_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    dependencies=[Depends(csrf_guard)],
)
def delete_bus(
    bus_id: int,
    db: Session = Depends(get_db),
    _admin: models.AppUser = Depends(require_admin),
):
    bus = db.query(models.Bus).filter(models.Bus.id == bus_id).first()
    if not bus:
        raise HTTPException(status_code=404, detail="Bus not found")
    dynsec_client.delete_bus_mqtt_client(bus.vehicle_id)
    db.delete(bus)
    db.commit()


@router.get("/buses", response_model=list[schemas.BusOut])
def list_buses(
    db: Session = Depends(get_db),
    user: models.AppUser = Depends(get_current_user),
):
    ids = assigned_bus_ids(user, db)
    if not ids:
        return []
    return db.query(models.Bus).filter(models.Bus.id.in_(ids)).all()
