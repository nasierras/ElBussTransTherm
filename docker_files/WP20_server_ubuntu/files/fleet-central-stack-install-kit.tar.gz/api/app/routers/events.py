import csv
import io
from datetime import datetime, timedelta, timezone
from typing import Literal, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import Response, StreamingResponse
from sqlalchemy import text
from sqlalchemy.engine import Row
from sqlalchemy.orm import Session

from .. import models, schemas
from ..config import settings
from ..database import get_db
from ..deps import assigned_bus_ids, get_current_user

router = APIRouter(tags=["events"])


def _resolve_bus_and_range(
    bus_id: int,
    since: Optional[datetime],
    until: Optional[datetime],
    db: Session,
    user: models.AppUser,
) -> tuple[models.Bus, datetime, datetime]:
    allowed_ids = assigned_bus_ids(user, db)
    if bus_id not in allowed_ids:
        raise HTTPException(status_code=403, detail="Not authorized for this bus")

    bus = db.query(models.Bus).filter(models.Bus.id == bus_id).first()
    if not bus:
        raise HTTPException(status_code=404, detail="Bus not found")

    if since is None:
        since = datetime.now(timezone.utc) - timedelta(hours=24)
    if until is None:
        until = datetime.now(timezone.utc)
    return bus, since, until


def _fetch_rows(bus: models.Bus, since: datetime, until: datetime, limit: int, db: Session) -> list[Row]:
    return db.execute(
        text(
            'SELECT "time", vehicle_id, trip_id, payload FROM fleet_events '
            'WHERE vehicle_id = :vehicle_id AND "time" BETWEEN :since AND :until '
            'ORDER BY "time" DESC LIMIT :limit'
        ),
        {"vehicle_id": bus.vehicle_id, "since": since, "until": until, "limit": limit},
    ).fetchall()


def flatten_payload(value, parent_key: str = "", sep: str = ".") -> dict:
    """Recursively flattens a nested dict into dot-notation columns, e.g.
    {"bus_environment": {"wp21i": {"temp_c": 21}}} -> {"bus_environment.wp21i.temp_c": 21}.
    Non-dict leaves (including lists, which this payload shape doesn't
    currently produce) are kept as-is."""
    items: dict = {}
    if isinstance(value, dict):
        if not value:
            items[parent_key] = None
        for k, v in value.items():
            new_key = f"{parent_key}{sep}{k}" if parent_key else k
            items.update(flatten_payload(v, new_key, sep))
    else:
        items[parent_key] = value
    return items


def _ordered_columns(fixed: list[str], flattened_rows: list[dict]) -> list[str]:
    dynamic = sorted({k for row in flattened_rows for k in row.keys()})
    return fixed + [c for c in dynamic if c not in fixed]


@router.get("/events", response_model=list[schemas.EventOut])
def list_events(
    bus_id: int = Query(...),
    since: Optional[datetime] = Query(None, alias="from"),
    until: Optional[datetime] = Query(None, alias="to"),
    limit: int = Query(settings.EVENTS_DEFAULT_LIMIT, le=settings.EVENTS_MAX_LIMIT, gt=0),
    db: Session = Depends(get_db),
    user: models.AppUser = Depends(get_current_user),
):
    bus, since, until = _resolve_bus_and_range(bus_id, since, until, db, user)
    rows = _fetch_rows(bus, since, until, limit, db)
    return [
        schemas.EventOut(time=r.time, vehicle_id=r.vehicle_id, trip_id=r.trip_id, payload=r.payload)
        for r in rows
    ]


@router.get("/events/export")
def export_events(
    bus_id: int = Query(...),
    since: Optional[datetime] = Query(None, alias="from"),
    until: Optional[datetime] = Query(None, alias="to"),
    format: Literal["csv", "xlsx"] = Query("csv"),
    limit: int = Query(settings.EVENTS_EXPORT_MAX_LIMIT, le=settings.EVENTS_EXPORT_MAX_LIMIT, gt=0),
    db: Session = Depends(get_db),
    user: models.AppUser = Depends(get_current_user),
):
    bus, since, until = _resolve_bus_and_range(bus_id, since, until, db, user)
    rows = _fetch_rows(bus, since, until, limit, db)

    flattened = []
    for r in rows:
        flat = flatten_payload(r.payload)
        flat["time"] = r.time.isoformat()
        flat["vehicle_id"] = r.vehicle_id
        flat["trip_id"] = r.trip_id
        flattened.append(flat)

    columns = _ordered_columns(["time", "vehicle_id", "trip_id"], flattened)
    filename_stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    filename = f"{bus.vehicle_id}_events_{filename_stamp}.{format}"

    if format == "csv":
        buffer = io.StringIO()
        writer = csv.DictWriter(buffer, fieldnames=columns, restval="", extrasaction="ignore")
        writer.writeheader()
        for row in flattened:
            writer.writerow(row)
        buffer.seek(0)
        return StreamingResponse(
            iter([buffer.getvalue()]),
            media_type="text/csv",
            headers={"Content-Disposition": f'attachment; filename="{filename}"'},
        )

    # xlsx
    from openpyxl import Workbook

    wb = Workbook()
    ws = wb.active
    ws.title = "events"
    ws.append(columns)
    for row in flattened:
        ws.append([row.get(c, "") for c in columns])

    output = io.BytesIO()
    wb.save(output)
    output.seek(0)
    return Response(
        content=output.read(),
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )
