from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session

from .. import models, schemas, security
from ..database import get_db
from ..deps import get_current_user

router = APIRouter(tags=["auth"])


@router.post("/auth/token", response_model=schemas.Token)
def login(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = db.query(models.AppUser).filter(models.AppUser.username == form_data.username).first()
    if not user or not user.is_active or not security.verify_password(form_data.password, user.password_hash):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Incorrect username or password")
    token = security.create_access_token(subject=user.username, role=user.role)
    return schemas.Token(access_token=token)


@router.get("/users/me", response_model=schemas.UserOut)
def read_current_user(user: models.AppUser = Depends(get_current_user)):
    return user
