import datetime as dt

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from .. import models, schemas, security
from ..database import get_db
from ..deps import get_current_user, require_admin
from ..web.deps import csrf_guard

router = APIRouter(tags=["users"])


@router.get("/users", response_model=list[schemas.UserOut])
def list_users(
    db: Session = Depends(get_db),
    _admin: models.AppUser = Depends(require_admin),
):
    return db.query(models.AppUser).order_by(models.AppUser.username).all()


@router.post(
    "/users",
    response_model=schemas.UserOut,
    status_code=status.HTTP_201_CREATED,
    dependencies=[Depends(csrf_guard)],
)
def create_user(
    body: schemas.UserCreate,
    db: Session = Depends(get_db),
    _admin: models.AppUser = Depends(require_admin),
):
    if body.role not in ("admin", "user"):
        raise HTTPException(status_code=422, detail="role must be 'admin' or 'user'")
    existing = db.query(models.AppUser).filter(models.AppUser.username == body.username).first()
    if existing:
        raise HTTPException(status_code=409, detail="Username already exists")

    new_user = models.AppUser(
        username=body.username,
        password_hash=security.hash_password(body.password),
        role=body.role,
    )
    db.add(new_user)
    db.commit()
    db.refresh(new_user)
    return new_user


@router.delete(
    "/users/{user_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    dependencies=[Depends(csrf_guard)],
)
def delete_user(
    user_id: int,
    db: Session = Depends(get_db),
    _admin: models.AppUser = Depends(require_admin),
):
    user = db.query(models.AppUser).filter(models.AppUser.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    db.delete(user)
    db.commit()


@router.patch("/users/me/password", status_code=status.HTTP_204_NO_CONTENT, dependencies=[Depends(csrf_guard)])
def change_own_password(
    body: schemas.PasswordChange,
    db: Session = Depends(get_db),
    user: models.AppUser = Depends(get_current_user),
):
    if not security.verify_password(body.current_password, user.password_hash):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Current password is incorrect")

    user.password_hash = security.hash_password(body.new_password)
    user.password_changed_at = dt.datetime.now(dt.timezone.utc)
    db.commit()


@router.put(
    "/admin/users/{user_id}/password",
    status_code=status.HTTP_204_NO_CONTENT,
    dependencies=[Depends(csrf_guard)],
)
def reset_user_password(
    user_id: int,
    body: schemas.PasswordReset,
    db: Session = Depends(get_db),
    _admin: models.AppUser = Depends(require_admin),
):
    user = db.query(models.AppUser).filter(models.AppUser.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    user.password_hash = security.hash_password(body.new_password)
    user.password_changed_at = dt.datetime.now(dt.timezone.utc)
    db.commit()


@router.post(
    "/buses/{bus_id}/assignments/{user_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    dependencies=[Depends(csrf_guard)],
)
def assign_bus(
    bus_id: int,
    user_id: int,
    db: Session = Depends(get_db),
    _admin: models.AppUser = Depends(require_admin),
):
    bus = db.query(models.Bus).filter(models.Bus.id == bus_id).first()
    user = db.query(models.AppUser).filter(models.AppUser.id == user_id).first()
    if not bus or not user:
        raise HTTPException(status_code=404, detail="Bus or user not found")

    existing = (
        db.query(models.UserBusAssignment)
        .filter_by(bus_id=bus_id, user_id=user_id)
        .first()
    )
    if not existing:
        db.add(models.UserBusAssignment(bus_id=bus_id, user_id=user_id))
        db.commit()


@router.delete(
    "/buses/{bus_id}/assignments/{user_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    dependencies=[Depends(csrf_guard)],
)
def unassign_bus(
    bus_id: int,
    user_id: int,
    db: Session = Depends(get_db),
    _admin: models.AppUser = Depends(require_admin),
):
    db.query(models.UserBusAssignment).filter_by(bus_id=bus_id, user_id=user_id).delete()
    db.commit()


@router.get("/admin/assignments")
def list_assignments(
    db: Session = Depends(get_db),
    _admin: models.AppUser = Depends(require_admin),
):
    rows = (
        db.query(
            models.UserBusAssignment.user_id,
            models.AppUser.username,
            models.UserBusAssignment.bus_id,
            models.Bus.vehicle_id,
        )
        .join(models.AppUser, models.AppUser.id == models.UserBusAssignment.user_id)
        .join(models.Bus, models.Bus.id == models.UserBusAssignment.bus_id)
        .order_by(models.AppUser.username, models.Bus.vehicle_id)
        .all()
    )
    return [
        {"user_id": r.user_id, "username": r.username, "bus_id": r.bus_id, "vehicle_id": r.vehicle_id}
        for r in rows
    ]
