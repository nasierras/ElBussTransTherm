from urllib.parse import urlparse

from fastapi import Depends, HTTPException, Request, status

from .. import models
from ..deps import get_current_user


def csrf_guard(request: Request, _user: models.AppUser = Depends(get_current_user)) -> None:
    """Origin/Referer check for state-changing endpoints.

    SameSite=Lax on the session cookie already blocks it from being sent on
    cross-site POST/PUT/PATCH/DELETE, but Lax still allows the cookie on a
    top-level cross-site GET navigation -- this closes that gap for the
    mutating endpoints it's attached to. Only applies to cookie-authenticated
    requests: an Authorization header (Swagger, scripts, the mobile-style API
    flow) is exempt, since that's never silently attached by a browser.
    """
    if getattr(request.state, "auth_source", "none") != "cookie":
        return

    origin = request.headers.get("origin") or request.headers.get("referer")
    if not origin:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Missing Origin/Referer")

    if urlparse(origin).hostname != request.url.hostname:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Cross-origin request blocked")
