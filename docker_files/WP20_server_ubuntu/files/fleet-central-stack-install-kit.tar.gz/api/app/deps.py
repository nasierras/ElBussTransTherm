import jwt
from fastapi import Depends, HTTPException, Request, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session

from . import models
from .config import settings
from .database import get_db
from .security import decode_access_token


class NotAuthenticatedException(HTTPException):
    """Raised instead of a bare 401 so the exception handler (registered in
    main.py) can redirect browser page requests to /login while still
    returning plain 401 JSON for API/Swagger callers."""

    def __init__(self):
        super().__init__(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Could not validate credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )


# auto_error=False: a missing Authorization header must NOT raise here by
# itself -- get_current_user below still needs a chance to fall back to the
# cookie before deciding auth truly failed.
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/auth/token", auto_error=False)


def _resolve_token(request: Request, header_token: str | None = Depends(oauth2_scheme)) -> str | None:
    request.state.auth_source = "none"
    if header_token:
        request.state.auth_source = "header"
        return header_token
    cookie_token = request.cookies.get(settings.SESSION_COOKIE_NAME)
    if cookie_token:
        request.state.auth_source = "cookie"
        return cookie_token
    return None


def get_current_user(
    token: str | None = Depends(_resolve_token), db: Session = Depends(get_db)
) -> models.AppUser:
    if not token:
        raise NotAuthenticatedException()

    try:
        payload = decode_access_token(token)
        username = payload.get("sub")
        issued_at = payload.get("iat")
        if username is None or issued_at is None:
            raise NotAuthenticatedException()
    except jwt.PyJWTError:
        raise NotAuthenticatedException()

    user = db.query(models.AppUser).filter(models.AppUser.username == username).first()
    if user is None or not user.is_active:
        raise NotAuthenticatedException()

    # A token issued before the user's last password change is stale --
    # otherwise resetting a compromised account's password wouldn't revoke
    # whatever token an attacker already holds.
    if user.password_changed_at and issued_at < user.password_changed_at.timestamp():
        raise NotAuthenticatedException()

    return user


def require_admin(user: models.AppUser = Depends(get_current_user)) -> models.AppUser:
    if user.role != "admin":
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Admin privileges required")
    return user


def assigned_bus_ids(user: models.AppUser, db: Session) -> list[int]:
    if user.role == "admin":
        return [b.id for b in db.query(models.Bus).all()]
    rows = (
        db.query(models.UserBusAssignment.bus_id)
        .filter(models.UserBusAssignment.user_id == user.id)
        .all()
    )
    return [r[0] for r in rows]
