import os


class Settings:
    DB_HOST = os.environ.get("DB_HOST", "timescaledb")
    DB_PORT = int(os.environ.get("DB_PORT", 5432))
    DB_NAME = os.environ.get("DB_NAME", "fleetdata")
    DB_USER = os.environ.get("DB_USER", "fleetuser")
    DB_PASSWORD = os.environ.get("DB_PASSWORD", "")

    JWT_SECRET = os.environ.get("JWT_SECRET", "")
    JWT_ALGORITHM = "HS256"
    JWT_EXPIRE_MINUTES = int(os.environ.get("JWT_EXPIRE_MINUTES", 20))
    WEB_SESSION_EXPIRE_MINUTES = int(os.environ.get("WEB_SESSION_EXPIRE_MINUTES", 120))
    SESSION_COOKIE_NAME = "access_token"
    # The API is plain HTTP today (no reverse-TLS in front of it yet) -- a
    # Secure cookie would simply never be sent by the browser over HTTP,
    # breaking login silently. Default to false for now; flip to true (via
    # env) once this sits behind TLS, otherwise the session cookie is only
    # HttpOnly + SameSite=Lax protected, not transport-encrypted.
    COOKIE_SECURE = os.environ.get("COOKIE_SECURE", "false").lower() == "true"

    BOOTSTRAP_ADMIN_USERNAME = os.environ.get("BOOTSTRAP_ADMIN_USERNAME", "admin")
    BOOTSTRAP_ADMIN_PASSWORD = os.environ.get("BOOTSTRAP_ADMIN_PASSWORD", "")

    DYNSEC_MQTT_HOST = os.environ.get("DYNSEC_MQTT_HOST", "mosquitto")
    DYNSEC_MQTT_PORT = int(os.environ.get("DYNSEC_MQTT_PORT", 8883))
    DYNSEC_MQTT_USERNAME = os.environ.get("DYNSEC_MQTT_USERNAME", "dynsec-admin")
    DYNSEC_MQTT_PASSWORD = os.environ.get("DYNSEC_MQTT_PASSWORD", "")
    DYNSEC_CA_CERT = os.environ.get("DYNSEC_CA_CERT", "/certs/ca.crt")

    INGESTOR_MQTT_USERNAME = os.environ.get("MQTT_INGESTOR_USERNAME", "ingestor")
    INGESTOR_MQTT_PASSWORD = os.environ.get("MQTT_INGESTOR_PASSWORD", "")

    EVENTS_MAX_LIMIT = 1000
    EVENTS_DEFAULT_LIMIT = 200
    EVENTS_EXPORT_MAX_LIMIT = int(os.environ.get("EVENTS_EXPORT_MAX_LIMIT", 20000))


settings = Settings()
