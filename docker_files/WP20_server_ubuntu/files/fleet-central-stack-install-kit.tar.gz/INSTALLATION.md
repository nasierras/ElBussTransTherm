# Guía de Instalación — Fleet Central Stack

Esta guía asume una máquina Linux limpia, con Docker y Docker Compose instalados.

## 1. Requisitos previos

```bash
docker --version
docker compose version

curl -fsSL https://get.docker.com | sh
sudo usermod -aG docker $USER
```

## 2. Clonar el repositorio

```bash
git clone <URL_DE_TU_REPO> fleet-central-stack
cd fleet-central-stack
```

## 3. Configurar variables de entorno

```bash
cp .env.example .env
nano .env
```

Rellena cada valor según tu entorno. Este archivo nunca se sube al repo.

## 4. Generar certificados TLS

```bash
chmod +x generate_certs.sh
./generate_certs.sh ./mosquitto/certs
```

## 5. Revisar la configuración de Mosquitto

Verifica que `mosquitto/config/mosquitto.conf` tenga:
persistence true
persistence_location /mosquitto/data/


## 6. Levantar el stack

```bash
docker compose up -d
docker compose ps
```

## 7. Configurar el primer usuario de Mosquitto (dynamic security)

```bash
docker exec -it fleet-mosquitto mosquitto_ctrl dynsec createClient <usuario_admin> --password <password_seguro>
docker exec -it fleet-mosquitto mosquitto_ctrl dynsec addClientRole <usuario_admin> admin
```

## 8. Configurar backups automáticos

```bash
chmod +x backup_mosquitto.sh
crontab -e
```

Agrega:

0 2 * * * /ruta/completa/a/backup_mosquitto.sh >> /ruta/a/backups/backup.log 2>&1


## 9. Verificación final

```bash
docker ps -a | grep mosquitto
openssl s_client -connect localhost:8883 -CAfile ./mosquitto/certs/ca.crt
```

## Checklist de seguridad antes de hacer push a un repo público

- [ ] `.env` está en `.gitignore` y NO aparece en `git status`
- [ ] Ningún archivo `.key`, `.crt` real está trackeado
- [ ] Ejecutaste `git log --all --full-history -- "*.env"` sin encontrar secretos
- [ ] Revisaste con `gitleaks detect --source . -v` antes del primer push
