#!/bin/bash
set -e

# ==== CONFIGURA ESTO ====
CONTAINER="fleet-mosquitto"
BASE_DIR="/home/elbusstranstherm/fleet-central-stack/mosquitto"
DATA_VOLUME="fleet-central-stack_mosquitto_data"
LOG_VOLUME="fleet-central-stack_mosquitto_log"   # opcional
BACKUP_DIR="/home/elbusstranstherm/backups/mosquitto"
# =========================

TIMESTAMP=$(date +%Y%m%d_%H%M%S)
DEST="${BACKUP_DIR}/${TIMESTAMP}"
mkdir -p "$DEST"

echo ">> Empacando config y certs (bind mounts)..."
tar czf "${DEST}/config.tar.gz" -C "$BASE_DIR" config
tar czf "${DEST}/certs.tar.gz" -C "$BASE_DIR" certs

echo ">> Empacando volumen de datos (mensajes retenidos, sesiones)..."
docker run --rm \
  -v "${DATA_VOLUME}":/data:ro \
  -v "${DEST}":/backup \
  alpine sh -c "tar czf /backup/mosquitto_data.tar.gz -C /data ."

echo ">> Empacando volumen de logs (opcional)..."
docker run --rm \
  -v "${LOG_VOLUME}":/logs:ro \
  -v "${DEST}":/backup \
  alpine sh -c "tar czf /backup/mosquitto_log.tar.gz -C /logs ."

echo ">> Backup completo en: ${DEST}"
ls -lh "${DEST}"
