#!/bin/bash
set -e

CERT_DIR="${1:-./mosquitto/certs}"
DAYS="${2:-3650}"

mkdir -p "$CERT_DIR"
cd "$CERT_DIR"

echo ">> Generando CA (autoridad certificadora local)..."
openssl genrsa -out ca.key 2048
openssl req -new -x509 -days "$DAYS" -key ca.key -out ca.crt \
  -subj "/C=SE/ST=Stockholm/O=FleetCentralStack/CN=FleetMQTT-CA"

echo ">> Generando llave y certificado del servidor Mosquitto..."
openssl genrsa -out server.key 2048
openssl req -new -key server.key -out server.csr \
  -subj "/C=SE/ST=Stockholm/O=FleetCentralStack/CN=fleet-mosquitto"

echo ">> Firmando el certificado del servidor con la CA local..."
openssl x509 -req -in server.csr -CA ca.crt -CAkey ca.key -CAcreateserial \
  -out server.crt -days "$DAYS" -sha256

rm -f server.csr ca.srl
chmod 600 server.key ca.key
chmod 644 server.crt ca.crt

echo ""
echo ">> Certificados generados en: $CERT_DIR"
ls -l "$CERT_DIR"
