"""
Fleet ingestor -- subscribes to every bus's forwarded combined record on the
central broker and writes it into the central TimescaleDB.

Topic pattern: fleet/{vehicle_id}/unified/combined
The vehicle_id used to attribute a row is taken from the TOPIC, not the
payload body -- the broker's dynamic-security ACL only lets a bus's MQTT
client publish under its own fleet/{vehicle_id}/# prefix, so the topic is
the trustworthy source of "which bus sent this", not anything inside the
JSON itself.

A message from a vehicle_id that isn't already a registered, active bus is
logged and dropped -- registration is an explicit admin action (POST
/buses), never implicit on first message.
"""

import json
import os
import time
from datetime import datetime, timezone

import paho.mqtt.client as mqtt
import psycopg2

MQTT_BROKER = os.environ.get("MQTT_BROKER", "mosquitto")
MQTT_PORT = int(os.environ.get("MQTT_PORT", 8883))
MQTT_USERNAME = os.environ.get("MQTT_INGESTOR_USERNAME", "ingestor")
MQTT_PASSWORD = os.environ.get("MQTT_INGESTOR_PASSWORD", "")
MQTT_CA_CERT = os.environ.get("MQTT_CA_CERT", "/certs/ca.crt")

DB_HOST = os.environ.get("DB_HOST", "timescaledb")
DB_PORT = int(os.environ.get("DB_PORT", 5432))
DB_NAME = os.environ.get("DB_NAME", "fleetdata")
DB_USER = os.environ.get("DB_USER", "fleetuser")
DB_PASSWORD = os.environ.get("DB_PASSWORD", "")

SUBSCRIBE_TOPIC = "fleet/+/unified/combined"

_active_bus_cache = {}
_active_bus_cache_at = 0.0
ACTIVE_BUS_CACHE_TTL_SEC = 30.0


def get_db_connection():
    return psycopg2.connect(
        host=DB_HOST, port=DB_PORT, dbname=DB_NAME, user=DB_USER, password=DB_PASSWORD
    )


def is_registered_active_bus(conn, vehicle_id):
    global _active_bus_cache, _active_bus_cache_at
    now = time.monotonic()
    if now - _active_bus_cache_at > ACTIVE_BUS_CACHE_TTL_SEC:
        with conn.cursor() as cur:
            cur.execute("SELECT vehicle_id FROM buses WHERE is_active = true")
            _active_bus_cache = {row[0] for row in cur.fetchall()}
        _active_bus_cache_at = now
    return vehicle_id in _active_bus_cache


def insert_event(conn, vehicle_id, record):
    trip_id = record.get("trip_id")
    ts = record.get("timestamp")
    try:
        event_time = datetime.fromisoformat(ts) if ts else datetime.now(timezone.utc)
    except ValueError:
        event_time = datetime.now(timezone.utc)

    with conn.cursor() as cur:
        cur.execute(
            'INSERT INTO fleet_events ("time", vehicle_id, trip_id, payload) VALUES (%s, %s, %s, %s)',
            (event_time, vehicle_id, trip_id, json.dumps(record)),
        )
    conn.commit()


def on_connect(client, userdata, flags, reason_code, properties=None):
    print(f"[MQTT] Connected (reason_code={reason_code}). Subscribing to {SUBSCRIBE_TOPIC}")
    client.subscribe(SUBSCRIBE_TOPIC, qos=1)


def on_message(client, userdata, msg):
    conn = userdata["conn"]
    parts = msg.topic.split("/")
    if len(parts) != 4 or parts[0] != "fleet" or parts[2:] != ["unified", "combined"]:
        print(f"[INGESTOR] Unexpected topic shape, ignoring: {msg.topic}")
        return
    vehicle_id = parts[1]

    try:
        record = json.loads(msg.payload.decode("utf-8"))
    except (json.JSONDecodeError, UnicodeDecodeError) as e:
        print(f"[INGESTOR] Bad payload on {msg.topic}: {e}")
        return

    try:
        if not is_registered_active_bus(conn, vehicle_id):
            print(f"[INGESTOR] Dropping message from unregistered/inactive bus: {vehicle_id}")
            return
        insert_event(conn, vehicle_id, record)
        print(f"[INGESTOR] Stored event for {vehicle_id} @ {record.get('timestamp')}")
    except psycopg2.Error as e:
        print(f"[DB] Insert failed for {vehicle_id}: {e}")
        conn.rollback()


def main():
    print("[INGESTOR] Starting fleet ingestor...")

    conn = None
    for attempt in range(30):
        try:
            conn = get_db_connection()
            print("[DB] Connected to central TimescaleDB.")
            break
        except psycopg2.OperationalError as e:
            print(f"[DB] Not ready yet ({e}); retrying in 2s... ({attempt + 1}/30)")
            time.sleep(2)
    if conn is None:
        raise RuntimeError("Could not connect to central TimescaleDB after 30 attempts.")

    client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, userdata={"conn": conn})
    client.username_pw_set(MQTT_USERNAME, MQTT_PASSWORD)
    client.tls_set(ca_certs=MQTT_CA_CERT)
    client.on_connect = on_connect
    client.on_message = on_message

    while True:
        try:
            client.connect(MQTT_BROKER, MQTT_PORT, keepalive=30)
            break
        except (ConnectionRefusedError, OSError) as e:
            print(f"[MQTT] Broker not ready yet ({e}); retrying in 2s...")
            time.sleep(2)

    client.loop_forever()


if __name__ == "__main__":
    main()
