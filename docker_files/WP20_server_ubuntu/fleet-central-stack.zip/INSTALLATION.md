# Guía de Instalación

Esta guía se fusionó con [`README.md`](README.md), que es ahora la única
fuente de verdad para instalar y desplegar este stack — incluye
requisitos previos, apertura de puertos, generación de certificados
(script `generate_certs.sh`, ya corregido), arranque paso a paso, cómo
probar sin TLS antes de tener IP/dominio público, cómo exponer el
dashboard con HTTPS automático una vez que sí lo tengas, backups y el
checklist de seguridad antes de subir el repo a un remoto público.

Mantener dos guías por separado fue justamente lo que hizo que esta
quedara desactualizada respecto al comportamiento real del stack (p. ej.
el paso de `mosquitto_ctrl dynsec createClient` de más abajo ya no aplica
— el registro de buses crea sus credenciales MQTT automáticamente vía
`POST /buses`, ver README.md → "Managing the fleet"). No se edita más
este archivo; ver README.md directamente.
