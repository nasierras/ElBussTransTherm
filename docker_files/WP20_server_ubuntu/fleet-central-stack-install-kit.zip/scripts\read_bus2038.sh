#!/bin/bash
# Prints a quick summary of what's stored for BUS_2038 -- row count, time
# range, and a handful of sample fields from the latest and oldest rows.
# Meant as a fast sanity check after populate_bus2038.py / load_bus2038.sh,
# without needing pgAdmin or the dashboard.
#
# Usage (from the repository root, stack must already be up):
#   ./scripts/read_bus2038.sh
set -e

echo ">> Row count and time range:"
docker compose exec -T timescaledb psql -U postgres -d fleetdata -c "
SELECT count(*) AS rows, min(time) AS first_event, max(time) AS last_event
FROM fleet_events WHERE vehicle_id = 'BUS_2038';
"

echo ">> Sample fields, oldest and newest event:"
docker compose exec -T timescaledb psql -U postgres -d fleetdata -c "
SELECT
  time,
  payload->'bus_environment'->'wp24i'->>'speed_kmh' AS speed_kmh,
  payload->'bus_environment'->'wp25i'->>'operational_soc_percent' AS soc_percent,
  payload->'bus_environment'->'wp23i'->'wp231_front'->>'d1_globe_temp_x_C' AS globe_temp_x_front,
  payload->'bus_environment'->'wp23i'->'wp231_front'->>'b2_open_door_state' AS door_state_front,
  payload->'bus_environment'->'wp23i'->'wp233_aux'->>'b2_ignition_state' AS ignition,
  payload->'thermal_dummies'->'thermal_dummy_wp261'->>'active' AS dummy1_active,
  payload->'thermal_dummies'->'thermal_dummy_wp262'->>'active' AS dummy2_active,
  payload->'thermal_dummies'->'thermal_dummy_wp263'->>'active' AS dummy3_active
FROM fleet_events WHERE vehicle_id = 'BUS_2038'
ORDER BY time ASC LIMIT 1;
"
docker compose exec -T timescaledb psql -U postgres -d fleetdata -c "
SELECT
  time,
  payload->'bus_environment'->'wp24i'->>'speed_kmh' AS speed_kmh,
  payload->'bus_environment'->'wp25i'->>'operational_soc_percent' AS soc_percent,
  payload->'bus_environment'->'wp23i'->'wp231_front'->>'d1_globe_temp_x_C' AS globe_temp_x_front,
  payload->'bus_environment'->'wp23i'->'wp231_front'->>'b2_open_door_state' AS door_state_front,
  payload->'bus_environment'->'wp23i'->'wp233_aux'->>'b2_ignition_state' AS ignition,
  payload->'thermal_dummies'->'thermal_dummy_wp261'->>'active' AS dummy1_active,
  payload->'thermal_dummies'->'thermal_dummy_wp262'->>'active' AS dummy2_active,
  payload->'thermal_dummies'->'thermal_dummy_wp263'->>'active' AS dummy3_active
FROM fleet_events WHERE vehicle_id = 'BUS_2038'
ORDER BY time DESC LIMIT 1;
"
