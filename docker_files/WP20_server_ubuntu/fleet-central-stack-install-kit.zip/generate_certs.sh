#!/bin/bash
set -e

# Usage: ./generate_certs.sh [cert_dir] [days] [extra SAN entries...]
#
# Extra SAN entries let you add the address buses will actually dial, e.g.
# the host's public IP or a domain once you have one:
#   ./generate_certs.sh ./mosquitto/certs 3650 IP:203.0.113.10
#   ./generate_certs.sh ./mosquitto/certs 3650 DNS:fleet.example.com
#
# You do NOT need a public domain to run this today -- DNS:mosquitto,
# DNS:localhost and IP:127.0.0.1 are always included, which is enough for
# the internal ingestor/api containers and same-host testing. Re-run this
# script later once you know the real public IP/domain, adding it as an
# extra SAN entry -- an existing CA (ca.key/ca.crt) in cert_dir is reused
# rather than replaced, so buses already trusting it don't need a new
# ca.crt; only the server cert (which carries the SAN) is regenerated.
#
# The server cert's SAN MUST include the Docker Compose service name
# ("mosquitto") -- the ingestor/api containers connect using that name via
# Docker's internal DNS, and hostname verification fails otherwise even
# though external bus connections (using the real IP) work fine.

CERT_DIR="${1:-./mosquitto/certs}"
DAYS="${2:-3650}"
shift 2 2>/dev/null || shift $# # drop the two positional args if present

SAN="DNS:mosquitto,DNS:localhost,IP:127.0.0.1"
for extra in "$@"; do
  SAN="$SAN,$extra"
done

mkdir -p "$CERT_DIR"
CERT_DIR="$(cd "$CERT_DIR" && pwd)" # resolve to absolute before cd'ing below
cd "$CERT_DIR"

if [ -f ca.key ] && [ -f ca.crt ]; then
  echo ">> CA existente encontrada en $CERT_DIR, reutilizando (no se toca la confianza ya distribuida a los buses)..."
else
  echo ">> Generando CA (autoridad certificadora local)..."
  openssl genrsa -out ca.key 2048
  openssl req -new -x509 -days "$DAYS" -key ca.key -out ca.crt \
    -subj "/C=SE/ST=Stockholm/O=FleetCentralStack/CN=FleetMQTT-CA"
fi

echo ">> Generando llave y certificado del servidor Mosquitto..."
echo "   SAN: $SAN"
openssl genrsa -out server.key 2048
openssl req -new -key server.key -out server.csr \
  -subj "/C=SE/ST=Stockholm/O=FleetCentralStack/CN=fleet-mosquitto"

cat > server_ext.cnf <<EOF
subjectAltName = $SAN
extendedKeyUsage = serverAuth
EOF

echo ">> Firmando el certificado del servidor con la CA local..."
openssl x509 -req -in server.csr -CA ca.crt -CAkey ca.key -CAcreateserial \
  -out server.crt -days "$DAYS" -sha256 -extfile server_ext.cnf

rm -f server.csr ca.srl server_ext.cnf
chmod 600 server.key ca.key
chmod 644 server.crt ca.crt

echo ""
echo ">> Certificados generados en: $CERT_DIR"
ls -l "$CERT_DIR"
