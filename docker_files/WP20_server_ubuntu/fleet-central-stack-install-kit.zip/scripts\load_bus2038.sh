#!/bin/bash
# Loads a SQL file (produced by populate_bus2038.py) into the running
# TimescaleDB container.
#
# Usage (from the repository root, stack must already be up):
#   ./scripts/load_bus2038.sh [path/to/seed.sql]
set -e

SQL_FILE="${1:-scripts/bus2038_seed.sql}"

if [ ! -f "$SQL_FILE" ]; then
  echo "No such file: $SQL_FILE" >&2
  echo "Generate it first: python3 scripts/populate_bus2038.py" >&2
  exit 1
fi

echo ">> Loading $SQL_FILE into fleetdata..."
docker compose exec -T timescaledb psql -U postgres -d fleetdata < "$SQL_FILE"
echo ">> Done. Verify with: ./scripts/read_bus2038.sh"
