#!/bin/bash
# Deletes every fleet_events row for BUS_2038. Does not touch other buses,
# and does not delete the bus registration itself (the row in the `buses`
# table) -- only its event history.
#
# Usage (from the repository root, stack must already be up):
#   ./scripts/clear_bus2038.sh
set -e

echo ">> Deleting all fleet_events rows for BUS_2038..."
docker compose exec -T timescaledb psql -U postgres -d fleetdata -c \
  "DELETE FROM fleet_events WHERE vehicle_id = 'BUS_2038';"
echo ">> Done."
