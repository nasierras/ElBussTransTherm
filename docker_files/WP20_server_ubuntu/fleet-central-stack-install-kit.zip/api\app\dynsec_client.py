"""
Client for the Mosquitto dynamic-security plugin's MQTT control protocol.

Talks to the broker directly over MQTT rather than shelling out to
`mosquitto_ctrl` -- that binary is bundled only in the official Eclipse
Mosquitto Docker image (Alpine/musl); neither Debian's nor Alpine's own
`mosquitto-clients` package includes it, and a musl-built binary won't run
in this image's glibc environment anyway. The wire format below (publish
{"commands": [...]} to $CONTROL/dynamic-security/v1, read the matching
entry back from the "responses" array on
$CONTROL/dynamic-security/v1/response, an "error" key marks failure) was
confirmed directly against a live broker, not guessed from docs alone.
"""

import json
import secrets
import threading

import paho.mqtt.client as mqtt

from .config import settings

_CONTROL_TOPIC = "$CONTROL/dynamic-security/v1"
_RESPONSE_TOPIC = "$CONTROL/dynamic-security/v1/response"


class DynsecError(RuntimeError):
    pass


def _send_command(command: dict) -> dict:
    """Publish one dynsec command and wait (up to 5s) for its response."""
    result = {}
    got_response = threading.Event()

    def on_connect(client, userdata, flags, rc, properties=None):
        client.subscribe(_RESPONSE_TOPIC, qos=1)
        client.publish(_CONTROL_TOPIC, json.dumps({"commands": [command]}), qos=1)

    def on_message(client, userdata, msg):
        payload = json.loads(msg.payload.decode("utf-8"))
        for r in payload.get("responses", []):
            if r.get("command") == command["command"]:
                result.update(r)
                got_response.set()

    client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
    client.username_pw_set(settings.DYNSEC_MQTT_USERNAME, settings.DYNSEC_MQTT_PASSWORD)
    client.tls_set(ca_certs=settings.DYNSEC_CA_CERT)
    client.on_connect = on_connect
    client.on_message = on_message
    client.connect(settings.DYNSEC_MQTT_HOST, settings.DYNSEC_MQTT_PORT, keepalive=10)
    client.loop_start()
    try:
        if not got_response.wait(timeout=5):
            raise DynsecError(f"No response from broker for command {command['command']!r}")
    finally:
        client.loop_stop()
        client.disconnect()

    if "error" in result:
        raise DynsecError(result["error"])
    return result


def _ignore_if_exists(fn):
    try:
        fn()
    except DynsecError as e:
        if "already exists" not in str(e).lower():
            raise


def _client_has_role(username: str, rolename: str) -> bool:
    """addClientRole on a client that already has that role doesn't fail
    with an "already exists"-style message like every other idempotent
    command here -- it fails with a bare "Internal error", which
    _ignore_if_exists can't distinguish from a real failure. Checked
    directly against a live broker: getClient's response always includes
    the client's current roles, so check first instead of trying and
    swallowing a specific error string."""
    try:
        result = _send_command({"command": "getClient", "username": username})
    except DynsecError:
        return False
    client = (result.get("data") or {}).get("client") or {}
    return any(r.get("rolename") == rolename for r in client.get("roles", []))


def bootstrap_roles_and_ingestor(ingestor_username: str, ingestor_password: str) -> None:
    """Idempotent -- safe to call on every API startup."""
    _ignore_if_exists(lambda: _send_command({"command": "createRole", "rolename": "bus-publisher"}))
    _ignore_if_exists(
        lambda: _send_command(
            {
                "command": "addRoleACL",
                "rolename": "bus-publisher",
                "acltype": "publishClientSend",
                "topic": "fleet/%u/#",
                "allow": True,
            }
        )
    )

    _ignore_if_exists(lambda: _send_command({"command": "createRole", "rolename": "fleet-subscriber"}))
    _ignore_if_exists(
        lambda: _send_command(
            {
                "command": "addRoleACL",
                "rolename": "fleet-subscriber",
                "acltype": "subscribePattern",
                "topic": "fleet/+/unified/combined",
                "allow": True,
            }
        )
    )
    _ignore_if_exists(
        lambda: _send_command(
            {
                "command": "addRoleACL",
                "rolename": "fleet-subscriber",
                "acltype": "publishClientReceive",
                "topic": "fleet/+/unified/combined",
                "allow": True,
            }
        )
    )

    _ignore_if_exists(
        lambda: _send_command(
            {"command": "createClient", "username": ingestor_username, "password": ingestor_password}
        )
    )
    if not _client_has_role(ingestor_username, "fleet-subscriber"):
        _send_command(
            {"command": "addClientRole", "username": ingestor_username, "rolename": "fleet-subscriber"}
        )


def create_bus_mqtt_client(vehicle_id: str) -> str:
    password = secrets.token_urlsafe(18)
    _send_command({"command": "createClient", "username": vehicle_id, "password": password})
    _send_command({"command": "addClientRole", "username": vehicle_id, "rolename": "bus-publisher"})
    return password


def delete_bus_mqtt_client(vehicle_id: str) -> None:
    _send_command({"command": "deleteClient", "username": vehicle_id})
