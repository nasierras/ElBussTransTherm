from pathlib import Path

from fastapi import APIRouter, Depends, Form, HTTPException, Request, status
from fastapi.responses import RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from .. import models, security
from ..config import settings
from ..database import get_db
from ..deps import get_current_user

router = APIRouter(include_in_schema=False)

APP_VERSION = "0.0.1"

templates = Jinja2Templates(directory=str(Path(__file__).resolve().parent.parent / "templates"))
templates.env.globals["APP_VERSION"] = APP_VERSION


def _set_session_cookie(response, username: str, role: str) -> None:
    token = security.create_access_token(
        subject=username, role=role, expire_minutes=settings.WEB_SESSION_EXPIRE_MINUTES
    )
    response.set_cookie(
        key=settings.SESSION_COOKIE_NAME,
        value=token,
        httponly=True,
        secure=settings.COOKIE_SECURE,
        samesite="lax",
        max_age=settings.WEB_SESSION_EXPIRE_MINUTES * 60,
    )


@router.get("/")
def index():
    return RedirectResponse("/dashboard", status_code=status.HTTP_303_SEE_OTHER)


@router.get("/login")
def login_page(request: Request, next: str = "/dashboard", error: str | None = None):
    return templates.TemplateResponse(
        request, "login.html", {"next": next, "error": error}
    )


@router.post("/login")
def login_submit(
    username: str = Form(...),
    password: str = Form(...),
    next: str = Form("/dashboard"),
    db: Session = Depends(get_db),
):
    user = db.query(models.AppUser).filter(models.AppUser.username == username).first()
    if not user or not user.is_active or not security.verify_password(password, user.password_hash):
        return RedirectResponse(
            f"/login?error=Invalid+username+or+password&next={next}",
            status_code=status.HTTP_303_SEE_OTHER,
        )

    redirect = RedirectResponse(next or "/dashboard", status_code=status.HTTP_303_SEE_OTHER)
    _set_session_cookie(redirect, user.username, user.role)
    return redirect


@router.get("/logout")
def logout():
    redirect = RedirectResponse("/login", status_code=status.HTTP_303_SEE_OTHER)
    redirect.delete_cookie(settings.SESSION_COOKIE_NAME)
    return redirect


@router.get("/dashboard")
def events_page(request: Request, user: models.AppUser = Depends(get_current_user)):
    return templates.TemplateResponse(request, "dashboard.html", {"user": user})


@router.get("/account")
def account_page(request: Request, user: models.AppUser = Depends(get_current_user)):
    return templates.TemplateResponse(request, "account.html", {"user": user})


@router.get("/admin")
def admin_page(request: Request, user: models.AppUser = Depends(get_current_user)):
    if user.role != "admin":
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Admin privileges required")
    return templates.TemplateResponse(request, "admin.html", {"user": user})
