#!/usr/bin/env python3
"""
Generates 24 hours of realistic BUS_2038 telemetry matching the current
WP2_payload_schema.json (globe temp x/y/z, wp233_aux zone, multiple
thermal_dummies with an active flag each) and writes it as a SQL script
that inserts it into fleet_events.

This does NOT touch the database directly -- it only writes a .sql file.
Load that file with load_bus2038.sh (see usage below). Pure Python
standard library only, no pip install needed.

Usage (from the repository root):
    python3 scripts/populate_bus2038.py [output.sql]
    ./scripts/load_bus2038.sh [output.sql]

Interval is 15 minutes (96 rows over 24h) by default -- deliberately, not
1-second: the API caps a single /events response at EVENTS_MAX_LIMIT=1000
rows, and the dashboard always asks for exactly 1000, so denser data than
this would only ever show its most recent ~16 minutes in the UI regardless
of the selected time window. Lower INTERVAL_SECONDS below if you need finer
granularity for a direct SQL/API investigation instead of the dashboard.
"""
import json
import math
import random
import copy
import sys
from datetime import datetime, timedelta, timezone

OUT_PATH = sys.argv[1] if len(sys.argv) > 1 else "scripts/bus2038_seed.sql"
VEHICLE_ID = "BUS_2038"
TRIP_ID = 2038
WINDOW_HOURS = 24
INTERVAL_SECONDS = 15 * 60  # 15 minutes -> 96 rows over 24h, see note above
ROWS = (WINDOW_HOURS * 3600) // INTERVAL_SECONDS

random.seed()  # real randomness -- this is meant to run fresh each time

# One entry per thermal dummy: (dummy number, active). Mirrors the example
# in WP2_payload_schema.json (dummy 1 and 3 active, dummy 2 inactive) so the
# dashboard's dummy selector has something real to switch between.
THERMAL_DUMMIES = [(1, True), (2, False), (3, True)]

BASE_SURFACE = {
    "head": {"temp_c": 31.5, "rh_percent": 60, "iav_m_per_s_x": 2.3, "iav_m_per_s_y": 2.3, "globe_temp_c": 31.5},
    "neck": {"temp_c": 31.5, "iav_m_per_s_x": 2.3, "iav_m_per_s_y": 2.3},
    "torso": {"temp_c": 31.5, "globe_temp_c": 31.5},
    "abdomen": {"temp_c": 31.5},
    "arms": {
        "temp_c_left_upper_arm": 31.5, "temp_c_right_upper_arm": 31.5,
        "temp_c_left_forearm": 31.5, "temp_c_right_forearm": 31.5,
        "temp_c_left_hand": 31.5, "temp_c_right_hand": 31.5,
    },
    "legs": {
        "temp_c_left_thigh": 31.5, "temp_c_right_thigh": 31.5,
        "temp_c_left_calf": 31.5, "temp_c_right_calf": 31.5,
        "temp_c_left_foot": 31.5, "temp_c_right_foot": 31.5,
        "globe_temp_c_feet": 31.5, "iav_m_per_s_x_feet": 2.3, "iav_m_per_s_y_feet": 2.3,
    },
    "auxiliary": {"cushion_temp_c": 31.5, "iav_m_per_s_aux_z1": 2.3, "iav_m_per_s_aux_z2": 2.3},
}

BASE_HEATER = {
    # pwm_status_pad_* is a 0-100% heater pad power level (replaced the
    # old on_status_pad_* on/off boolean) -- see WP2_payload_schema.json.
    "temp_head": 35.8, "pwm_status_pad_head": 65,
    "temp_chest_left": 35.8, "pwm_status_pad_chest_left": 65,
    "temp_chest_right": 35.8, "pwm_status_pad_chest_right": 65,
    "temp_abdomen": 35.8, "pwm_status_pad_abdomen": 65,
    "temp_tight_left": 35.8, "pwm_status_pad_tight_left": 65,
    "temp_tight_right": 35.8, "pwm_status_pad_tight_right": 65,
    "temp_upper_left_arm": 35.8, "pwm_status_pad_upper_left_arm": 65,
    "temp_upper_right_arm": 35.8, "pwm_status_pad_upper_right_arm": 65,
    "temp_lower_left_arm": 35.8, "pwm_status_pad_lower_left_arm": 65,
    "temp_lower_right_arm": 35.8, "pwm_status_pad_lower_right_arm": 65,
    "temp_left_hand": 35.8, "pwm_status_pad_left_hand": 65,
    "temp_right_hand": 35.8, "pwm_status_pad_right_hand": 65,
    "temp_lower_left_leg": 35.8, "pwm_status_pad_lower_left_leg": 65,
    "temp_lower_right_leg": 35.8, "pwm_status_pad_lower_right_leg": 65,
    "temp_left_foot": 35.8, "pwm_status_pad_left_foot": 65,
    "temp_right_foot": 35.8, "pwm_status_pad_right_foot": 65,
}


def jit(value, spread):
    return value + random.uniform(-spread, spread)


def diurnal(hour):
    """0 at night, peaking at 1 around noon -- used to drive the day/night
    temperature and solar-irradiance cycle."""
    if 6 <= hour <= 18:
        return math.sin(math.pi * (hour - 6) / 12)
    return 0.0


def escape_sql(value):
    return value.replace("'", "''")


def build_bus_environment(temp_offset, solar_scale, is_daytime, speed_kmh, lat, lon, clo, met):
    return {
        "wp21i": {
            "wp211_front": {
                "c1_temp_C_head_standing": round(jit(23.4 + temp_offset, 0.3), 2),
                "c2_temp_C_head_seated": round(jit(24.1 + temp_offset, 0.3), 2),
                "c3_temp_C_abdomen_seated": round(jit(16.0 + temp_offset, 0.3), 2),
                "c4_temp_C_ankle_feet": round(jit(25.0 + temp_offset, 0.3), 2),
                "k1_temp_C_control": round(jit(16.0 + temp_offset, 0.3), 2),
            },
            "wp212_middle": {
                "c1_temp_C_head_standing": round(jit(23.4 + temp_offset, 0.3), 2),
                "c2_temp_C_head_seated": round(jit(24.1 + temp_offset, 0.3), 2),
                "c3_temp_C_abdomen_seated": round(jit(16.0 + temp_offset, 0.3), 2),
                "c4_temp_C_ankle_feet": round(jit(25.0 + temp_offset, 0.3), 2),
                "k1_temp_C_control": round(jit(16.0 + temp_offset, 0.3), 2),
            },
            "wp213_rear": {
                "c1_temp_C_head_standing": round(jit(23.4 + temp_offset, 0.3), 2),
                "c2_temp_C_head_seated": round(jit(24.1 + temp_offset, 0.3), 2),
                "c3_temp_C_abdomen_seated": round(jit(16.0 + temp_offset, 0.3), 2),
                "c4_temp_C_ankle_feet": round(jit(25.0 + temp_offset, 0.3), 2),
                "k1_temp_C_control": round(jit(16.0 + temp_offset, 0.3), 2),
            },
        },
        "wp22i": {
            zone: {
                "a1_iav_x_m_per_s": round(max(0, jit(1.8, 0.3)), 2),
                "a1_iav_y_m_per_s": round(max(0, jit(2.8, 0.3)), 2),
                "a1_iav_z_m_per_s": round(max(0, jit(3.8, 0.3)), 2),
                "a2_co2_ppm": round(max(400, jit(670 * is_daytime, 25))),
                "a2_temp_C": round(jit(12.5 + temp_offset, 0.3), 2),
                "a2_RH_percent": round(max(20, min(80, jit(65.8, 2))), 2),
                "b2_pm001_mum": round(max(0, jit(30.0, 3)), 2),
                "b2_pm025_mum": round(max(0, jit(50.0, 4)), 2),
                "b2_pm040_mum": round(max(0, jit(75.0, 5)), 2),
                "b2_pm100_mum": round(max(0, jit(120.0, 6)), 2),
                "a3_solar_irradiance_w_per_m2": round(max(0, jit(810.0 * solar_scale, 15))),
            }
            for zone in ("wp221_front", "wp222_right", "wp223_left")
        },
        # Globe temp is now three axes (x/y/z) per zone instead of one
        # scalar -- see WP2_payload_schema.json. Ignition is a single
        # vehicle-wide signal reported once, on wp233_aux (b2_ignition_state)
        # -- distinct from b2_open_door_state, which the other three zones
        # report per physical door.
        "wp23i": {
            "wp231_front": {
                "b1_RH_percent": round(jit(23.4, 1.5), 2),
                "d1_globe_temp_x_C": round(jit(24.1 + temp_offset, 0.3), 2),
                "d1_globe_temp_y_C": round(jit(24.1 + temp_offset, 0.3), 2),
                "d1_globe_temp_z_C": round(jit(24.1 + temp_offset, 0.3), 2),
                "b2_open_door_state": speed_kmh < 0.5 and random.random() < 0.3,
            },
            "wp232_middle": {
                "b1_RH_percent": round(jit(23.4, 1.5), 2),
                "d1_globe_temp_x_C": round(jit(24.1 + temp_offset, 0.3), 2),
                "d1_globe_temp_y_C": round(jit(24.1 + temp_offset, 0.3), 2),
                "d1_globe_temp_z_C": round(jit(24.1 + temp_offset, 0.3), 2),
                "b2_open_door_state": speed_kmh < 0.5 and random.random() < 0.3,
            },
            "wp233_rear": {
                "b1_RH_percent": round(jit(23.4, 1.5), 2),
                "d1_globe_temp_x_C": round(jit(24.1 + temp_offset, 0.3), 2),
                "d1_globe_temp_y_C": round(jit(24.1 + temp_offset, 0.3), 2),
                "d1_globe_temp_z_C": round(jit(24.1 + temp_offset, 0.3), 2),
                "b2_open_door_state": speed_kmh < 0.5 and random.random() < 0.3,
            },
            "wp233_aux": {
                "b1_RH_percent": round(jit(23.4, 1.5), 2),
                "d1_globe_temp_x_C": round(jit(24.1 + temp_offset, 0.3), 2),
                "d1_globe_temp_y_C": round(jit(24.1 + temp_offset, 0.3), 2),
                "d1_globe_temp_z_C": round(jit(24.1 + temp_offset, 0.3), 2),
                "b2_ignition_state": speed_kmh > 0.5 or random.random() < 0.85,
            },
        },
        "wp24i": {
            "aps": 8, "lat": round(lat, 6), "lon": round(lon, 6),
            "speed_kmh": round(speed_kmh, 2), "clo": round(clo, 3), "met": round(met, 3),
        },
        "wp25i": {
            "fuel_heater_hours": 15,
            "hvess_remaining_distance_km": round(max(5, 100 - temp_offset), 1),
            "operational_soc_percent": round(max(15, min(100, 85 - temp_offset)), 1),
            "cumulated_energy_charged_kwh": round(530.15 + random.uniform(0, 5), 2),
            "regenerative_braking_cumulated_energy_kwh": round(120.08 + random.uniform(0, 2), 2),
            "hvac_cumulated_energy_kwh": round(35.15 + random.uniform(0, 2), 2),
            "air_compressor_cumulated_energy_kwh": round(19.15 + random.uniform(0, 1), 2),
            "auxiliaries_cumulated_energy_kwh": round(4.18 + random.uniform(0, 0.5), 2),
        },
    }


def build_thermal_dummies(temp_offset):
    result = {}
    for num, active in THERMAL_DUMMIES:
        surface = copy.deepcopy(BASE_SURFACE)
        if active:
            for segment in surface.values():
                for key in list(segment.keys()):
                    if "temp" in key:
                        segment[key] = round(jit(segment[key] + temp_offset * 0.5, 0.2), 2)
        result[f"thermal_dummy_wp26{num}"] = {"active": active, "surface": surface}

        heater = copy.deepcopy(BASE_HEATER)
        if active:
            for key in list(heater.keys()):
                if key.startswith("temp_"):
                    heater[key] = round(jit(heater[key] + temp_offset * 0.3, 0.15), 2)
                elif key.startswith("pwm_status_pad_"):
                    heater[key] = round(max(0, min(100, jit(heater[key], 15))))
        result[f"internal_wp2tm{num}"] = heater
    return result


def main():
    now = datetime.now(timezone.utc).replace(microsecond=0)
    start = now - timedelta(seconds=WINDOW_HOURS * 3600)

    lat, lon, heading = 59.3293, 18.0686, 0.7

    print(f"Generating {ROWS} rows for {VEHICLE_ID} from {start.isoformat()} to {now.isoformat()}...", file=sys.stderr)

    with open(OUT_PATH, "w") as f:
        f.write(f"DELETE FROM fleet_events WHERE vehicle_id = '{VEHICLE_ID}';\n")
        f.write("BEGIN;\n")

        for i in range(ROWS):
            t = start + timedelta(seconds=i * INTERVAL_SECONDS)
            hour = t.hour + t.minute / 60 + t.second / 3600
            d = diurnal(hour)
            temp_offset = -4.0 * (1 - d)
            solar_scale = d
            is_daytime = 1 if (7 <= hour <= 19) else 0.4

            minute_of_day = (i * INTERVAL_SECONDS) / 60.0
            speed_kmh = max(0.0, 40 * abs(math.sin(2 * math.pi * minute_of_day / 20)) + random.uniform(-4, 4))
            if (int(minute_of_day) % 45) < 3:
                speed_kmh = 0.0
            if not (5 <= hour <= 23):
                speed_kmh *= 0.15
            heading += random.uniform(-0.05, 0.05)
            distance_deg = (speed_kmh * INTERVAL_SECONDS / 3600.0) / 111.0
            lat += distance_deg * math.cos(heading)
            lon += distance_deg * math.sin(heading)
            clo = max(0.5, 1.2 + 0.3 * (1 - d) + random.uniform(-0.02, 0.02))
            met = max(0.3, 0.5 + random.uniform(-0.05, 0.05))

            payload = {
                "timestamp": t.isoformat(),
                "timestamp_utc": int(t.timestamp()),
                "vehicle_id": VEHICLE_ID,
                "trip_id": TRIP_ID,
                "bus_environment": build_bus_environment(temp_offset, solar_scale, is_daytime, speed_kmh, lat, lon, clo, met),
                "thermal_dummies": build_thermal_dummies(temp_offset),
                "diagnostics": {"mqtt_connected": True, "sensor_faults": [], "watchdog_triggered": False},
            }

            payload_json = escape_sql(json.dumps(payload, separators=(",", ":")))
            f.write(
                "INSERT INTO fleet_events (time, vehicle_id, trip_id, payload) VALUES "
                f"('{t.isoformat()}', '{VEHICLE_ID}', {TRIP_ID}, '{payload_json}'::jsonb);\n"
            )

        f.write("COMMIT;\n")

    print(f"Done. Wrote {ROWS} rows to {OUT_PATH}", file=sys.stderr)
    print(f"Load it with: ./scripts/load_bus2038.sh {OUT_PATH}", file=sys.stderr)


if __name__ == "__main__":
    main()
