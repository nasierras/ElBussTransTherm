from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy.orm import Session

from . import dynsec_client, models, security
from .config import settings
from .database import SessionLocal
from .deps import NotAuthenticatedException
from .routers import auth, buses, events, users
from .web import routes as web_routes


@asynccontextmanager
async def lifespan(app: FastAPI):
    db: Session = SessionLocal()
    try:
        admin_exists = db.query(models.AppUser).filter(models.AppUser.role == "admin").first()
        if not admin_exists and settings.BOOTSTRAP_ADMIN_PASSWORD:
            admin = models.AppUser(
                username=settings.BOOTSTRAP_ADMIN_USERNAME,
                password_hash=security.hash_password(settings.BOOTSTRAP_ADMIN_PASSWORD),
                role="admin",
            )
            db.add(admin)
            db.commit()
            print(f"[API] Bootstrap admin '{settings.BOOTSTRAP_ADMIN_USERNAME}' created.")
    finally:
        db.close()

    try:
        dynsec_client.bootstrap_roles_and_ingestor(
            settings.INGESTOR_MQTT_USERNAME, settings.INGESTOR_MQTT_PASSWORD
        )
        print("[API] Dynamic-security roles bootstrapped.")
    except Exception as e:
        print(f"[API] WARNING: dynsec bootstrap failed: {e}")

    yield


# Swagger UI lives at /swagger/index.html instead of FastAPI's default
# /docs; the OpenAPI JSON schema stays at the default /openapi.json.
app = FastAPI(title="ElBussTransTherm Fleet API", lifespan=lifespan, docs_url="/swagger/index.html")

app.mount(
    "/static", StaticFiles(directory=str(Path(__file__).resolve().parent / "static")), name="static"
)

# Every JSON API route lives under /api/v1 -- /healthz stays unprefixed and
# unversioned on purpose (it's an ops/orchestration endpoint, e.g. Docker
# healthchecks, not part of the versioned API surface), and the web_routes
# router (HTML pages: /login, /dashboard, /account, /admin) is also
# unprefixed since those aren't "the API".
API_PREFIX = "/api/v1"
app.include_router(auth.router, prefix=API_PREFIX)
app.include_router(buses.router, prefix=API_PREFIX)
app.include_router(users.router, prefix=API_PREFIX)
app.include_router(events.router, prefix=API_PREFIX)
app.include_router(web_routes.router)


@app.exception_handler(NotAuthenticatedException)
async def not_authenticated_handler(request: Request, exc: NotAuthenticatedException):
    # Browser page navigations (Accept: text/html) get bounced to the login
    # page; API/Swagger/script callers keep getting a plain 401 so existing
    # bearer-token clients don't see any behavior change.
    if "text/html" in request.headers.get("accept", ""):
        next_path = request.url.path
        return RedirectResponse(f"/login?next={next_path}", status_code=303)
    return JSONResponse(status_code=exc.status_code, content={"detail": exc.detail}, headers=exc.headers)


@app.get("/healthz")
def healthz():
    return {"status": "ok"}
